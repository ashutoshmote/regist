

<?php

include '../databaseconnection/databasesociety.php';
////////////////////////////////////Signup////////////////////////////////////

$signupoutput = "";
if (isset($_REQUEST['signbtn'])) {
    if (!empty($_POST['sign_name'])) {
        $login_name = $_POST['sign_name'];
        $login_email = $_POST['sign_email'];
        $login_password = $_POST['sign_pwd'];
        $login_repassword = $_POST['sign_repwd'];

        $loginresult = signupinsert($login_name, $login_email, $login_password, $login_repassword);
        if ($loginresult > 0) {
            if ($login_password != $login_repassword) {
                echo 'Password Not match' . $signupoutput;
                exit;
            } else {
                header("Location:login.php") . $signupoutput;
            }
        } else {
            echo "<div class='alert alert-danger'>" . " <strong>Unsuccess!</strong> " . "</div>";
        }
    }
}
////////////////////////////////////login////////////////////////////////////


session_start();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $email = $_POST['login_email'];
    $password = $_POST['login_pwd'];
    $login_result = login($email, $password);


    if (count($login_result) > 0) {
        if ($login_result["login_registertype"] == 1) {
            echo 'Login Successful ';
            header("Location:./admin_society/admin_societyview.php");
            $_SESSION["user"] = $login_result['login_id'];
            echo $_SESSION["user"];
        }
    } else {
        echo 'Please Check Your unsername or Password';
    }
}
?>
<?php include './admin_header.php'; ?>
<section id="contents" style="background-image: url(../Insurance/asfalt-dark.png)">
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <i class="fa fa-align-right"></i>
                </button>
                <a class="navbar-brand" href="#">my<span class="main-color">Dashboard</span></a>
            </div>
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav" style="margin-top: 10px;">
                    <li><a href="#"><i data-show="show-side-navigation1" class="fa fa-bars show-side-btn"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <br>
    <div class="container-fluid box justify-content-center">


        <div class="login-box">
            <div class="lb-header" style="margin-top:10px;text-align: center">
                <a href="#" class="active" id="login-box-link">Admin Login</a>
            </div>


            <form method="POST" class="email-login">

                <div class="u-form-group">
                    <input type="email" placeholder="Email" name="login_email"/>
                </div>
                <div class="u-form-group">
                    <input type="password" placeholder="Password" name="login_pwd"/>
                </div>
                <div class="u-form-group" style="margin-top: 40px">
                    <button>Log in</button>
                </div>
                <div class="u-form-group">
                    <a href="#" class="forgot-password">Forgot password?</a>
                </div>

            </form>
            <!--            ///////////////////////Sign-Up/////////////////////////////-->

        </div>
    </div>
</section>
<br />

<?php

include './admin_footer.php';
?>