<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta name = "viewport" content = "width=device-width, initial-scale=1.0">
        <!--<bootsrap file> -->
        <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <!--<bootsrap file> -->
        <!--<Fontawsome> -->
        <link href = "https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel = "stylesheet">
        <!--< End Fontawsome> -->

        <!--<google font Start> -->
        <link href = "https://fonts.googleapis.com/css?family=Montserrat|Oswald|Roboto|Roboto+Slab&display=swap" rel = "stylesheet">
        <!--<google font Stop> -->

        <link href = "../css/registerform.css" rel = "stylesheet" type = "text/css"/>
    </head>
    <body>
        <?php
        include '../../databaseconnection/databasesociety.php';
        session_start();
        $output = '';


        if (isset($_POST["export_excel"])) {

            $societyexport = admin_societyshow();
            if ($societyexport > 0) {
                $output .= '<table class="table"  border="1">
                      <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Address</th>
                      <th>email</th>
                      <th>Other email</th>
                      <th>Manager</th>
                      <th>Manager Contact</th>
                      <th>Chairman</th>
                      <th>Chairman Contact</th>
                      <th>Secretary</th>
                      <th>Secretary_contact</th>
                      <th>Treasurer</th>
                      <th>Treasurer Contact</th>
                      <th>Insured</th>
                      <th>existing insure</th>
                      <th>policy name</th>
                      <th>expiry date</th>
                      <th>agent</th>
                      <th>expiring sum</th>
                      <th>area mtft</th>
                      <th>no floor</th>
                      <th>no wing</th>
                      <th>no flat</th>
                      <th>totalbuild area</th>
                      <th>area perflat</th>
                      <th>basement</th>
                      <th>basement area</th>
                      <th>meter room</th>
                      <th>meter area</th>
                      <th>water tank</th>
                      <th>water tankcapacity</th>
                      <th>inverter</th>
                      <th>inverter time</th>
                      <th>society office</th>
                      <th>society officearea</th>
                      <th>Ac</th>
                      <th>water pumps</th>
                      <th>common</th>
                      <th>common area</th>
                      <th>sewage</th>
                      <th>garbage</th>
                      <th>remark</th>
                      <th>cctv</th>
                      <th>cctv total</th>
                      <th>fire system</th>
                      <th>fire systemtotal</th>
                      <th>physical security</th>
                      <th>no gaurds</th>
                      <th>audited</th>
                      <th>type</th>
                      <th>security remark</th>
                      <th>power back</th>
                      <th>club</th>
                      <th>club area</th>
                      <th>swimming</th>
                      <th>swimming area</th>
                      <th>inhouse</th>
                      <th>amenities area</th>
                      <th>overall remark</th>
                      </tr> ';
                foreach ($societyexport as $row) {
                    $insured = $row["insured"] == 1 ? "Insured" : "Uninsured";
                    $basement = $row["basement"] == 1 ? "Yes" : "No";
                    $meter_room = $row["meter_room"] == 1 ? "Yes" : "No";
                    $water_tank = $row["water_tank"] == 1 ? "Yes" : "No";
                    $inverter = $row["inverter"] == 1 ? "Yes" : "No";
                    $society_office = $row["society_office"] == 1 ? "Yes" : "No";
                    $ac = $row["ac"] == 1 ? "Yes" : "No";
                    $water_pumps = $row["water_pumps"] == 1 ? "Yes" : "No";
                    $common_areaa = $row["common"] == 1 ? "Yes" : "No";
                    $sewage = $row["sewage"] == 1 ? "Yes" : "No";
                    $garbage = $row["garbage"] == 1 ? "Yes" : "No";
                    $cctv = $row["cctv"] == 1 ? "Yes" : "No";
                    $fire_system = $row["fire_system"] == 1 ? "Yes" : "No";
                    $physical_security = $row["physical_security"] == 1 ? "Yes" : "No";

                    $audited = $row["audited"] == 1 ? "Yes" : "No";
                    $club = $row["club"] == 1 ? "Yes" : "No";
                    $swimming = $row["swimming"] == 1 ? "Yes" : "No";
                    $output .= '<tr>
                      <td>' . $row["id"] . '</td>
                      <td>' . $row["name"] . '</td>
                      <td> ' . $row["address"] . '</td>
                      <td>' . $row["email"] . '</td>
                      <td> ' . $row["alternateemail"] . ' </td>
                      <td>' . $row["manager"] . '</td>
                      <td> ' . $row["manager_contact"] . '</td>
                      <td> ' . $row["chairman"] . '</td>
                      <td> ' . $row["chairman_contact"] . '</td>
                      <td> ' . $row["secretary"] . '</td>
                      <td> ' . $row["secretary_contact"] . ' </td>
                      <td> ' . $row["treasurer"] . '</td>
                      <td> ' . $row["treasurer_contact"] . ' </td>
                      <td>' . $insured . '</td>
                      <td>' . $row["existing_insure"] . ' </td>
                      <td>' . $row["policy_name"] . '</td>
                      <td> ' . $row["expiry_date"] . ' </td>
                      <td> ' . $row["agent"] . '</td>
                      <td> ' . $row["expiring_sum"] . '</td>
                      <td> ' . $row["area_mtft"] . '</td>
                      <td> ' . $row["no_floor"] . ' </td>
                      <td> ' . $row["no_wing"] . ' </td>
                      <td> ' . $row["no_flat"] . ' </td>
                      <td> ' . $row["totalbuild_area"] . ' </td>
                      <td> ' . $row["area_perflat"] . ' </td>
                      <td>' . $basement . ' </td>
                      <td>' . $row["basement_area"] . ' </td>
                      <td> ' . $meter_room . ' </td>
                      <td> ' . $row["meter_area"] . ' </td>
                      <td> ' . $water_tank . ' </td>
                      <td> ' . $row["water_tankcapacity"] . ' </td>
                      <td> ' . $inverter . '</td>
                      <td> ' . $row["inverter_time"] . '</td>
                      <td> ' . $society_office . '</td>
                      <td> ' . $row["society_officearea"] . ' </td>
                      <td> ' . $ac . '</td>
                      <td> ' . $water_pumps . '</td>
                      <td> ' . $common_areaa . '</td>
                      <td> ' . $row["common_area"] . ' </td>
                      <td> ' . $sewage . '</td>
                      <td> ' . $garbage . '</td>
                      <td>' . $row["remark"] . '</td>
                      <td>' . $cctv . ' </td>
                      <td>' . $row["cctv_total"] . ' </td>
                      <td>' . $fire_system . '</td>
                      <td>' . $row["fire_systemtotal"] . ' </td>
                      <td>' . $physical_security . '</td>
                      <td> ' . $row["no_gaurds"] . '</td>
                      <td>' . $audited . '</td>
                      <td>' . $row["type"] . '</td>
                      <td>' . $row["security_remark"] . '</td>
                      <td>' . $row["power_back"] . '</td>
                      <td>' . $club . ' </td>
                      <td> ' . $row["club_area"] . ' </td>
                      <td> ' . $swimming . ' </td>
                      <td> ' . $row["swimming_area"] . ' </td>
                      <td>' . $row["inhouse"] . '</td>
                      <td> ' . $row["amenities_area"] . ' </td>
                      <td> ' . $row["overall_remark"] . '</td>
            </tr>';
                }
                $output .= '</table>';
                @header("Content-type:applicaltion/xls");
                @header("Content-Disposition: attachment; filename=society.xls");
                echo $output;
            }
        }
        ?>

        <div class="container text-center">
            <div class="table-responsive mt-5">
                <!--<h2>Export Mysql data into excel</h2>-->
                <!--                <div class="" id="live_data ">

                                    <form action="" method="POST">
                                        <input type="submit" name="export_excel" class="btn btn-success" value="Society Excel"/>
                                        <button name="export_excel" class="btn btn-success">Society Excel</button>
                                    </form>
                                </div>-->
            </div>
        </div>
    </body>
</html>
