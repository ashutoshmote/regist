$("#seeAnotherField").change(function() {
  //if insured
  if ($(this).val() == "1") {
    $('#1').show();
    $('#otherField').attr('required', '');
    $('#otherField').attr('data-error', 'This field is required.');
    $('#otherField1').attr('required', '');
    $('#otherField1').attr('data-error', 'This field is required.');
    $('#otherField2').attr('required', '');
    $('#otherField2').attr('data-error', 'This field is required.');
    $('#otherField3').attr('required', '');
    $('#otherField3').attr('data-error', 'This field is required.');
    $('#otherField4').attr('required', '');
    $('#otherField4').attr('data-error', 'This field is required.');
    $('#otherField5').attr('required', '');
    $('#otherField5').attr('data-error', 'This field is required.');
      } else {
    $('#1').hide();
    $('#otherField').removeAttr('required');
    $('#otherField').removeAttr('data-error');
    $('#otherField1').removeAttr('required');
    $('#otherField1').removeAttr('data-error');
    $('#otherField2').removeAttr('required');
    $('#otherField2').removeAttr('data-error');
    $('#otherField3').removeAttr('required');
    $('#otherField3').removeAttr('data-error');
    $('#otherField4').removeAttr('required');
    $('#otherField4').removeAttr('data-error');
    $('#otherField5').removeAttr('required');
    $('#otherField5').removeAttr('data-error');
  }
  //if uninsured
  if ($(this).val() == "2") {
    $('#otherFieldDiv').show();
    $('#otherField').attr('required', '');
    $('#otherField').attr('data-error', 'This field is required.');
    $('#otherFieldarea').attr('required', '');
    $('#otherFieldarea').attr('data-error', 'This field is required.');
    $('#otherField_floor').attr('required', '');
    $('#otherField_floor').attr('data-error', 'This field is required.');
    
    $('#otherField_wing').attr('required', '');
    $('#otherField_wing').attr('data-error', 'This field is required.');
    $('#otherField_flat').attr('required', '');
    $('#otherField_flat').attr('data-error', 'This field is required.');
    $('#otherField_build').attr('required', '');
    $('#otherField_build').attr('data-error', 'This field is required.');
    $('#otherField_perflat').attr('required', '');
    $('#otherField_perflat').attr('data-error', 'This field is required.');
    
    $('#otherField_gaurd').attr('required', '');
    $('#otherField_gaurd').attr('data-error', 'This field is required.');
      }
      else {
    $('#otherFieldDiv').hide();
    $('#otherField').removeAttr('required');
    $('#otherField').removeAttr('data-error');
    $('#otherFieldarea').removeAttr('required');
    $('#otherFieldarea').removeAttr('data-error');
    $('#otherField_floor').removeAttr('required');
    $('#otherField_floor').removeAttr('data-error');       
    $('#otherField_wing').removeAttr('required');
    $('#otherField_wing').removeAttr('data-error');
    $('#otherField_flat').removeAttr('required');
    $('#otherField_flat').removeAttr('data-error');
    $('#otherField_build').removeAttr('required');
    $('#otherField_build').removeAttr('data-error');
    $('#otherField_perflat').removeAttr('required');
    $('#otherField_perflat').removeAttr('data-error');
    
    $('#otherField_gaurd').removeAttr('required');
    $('#otherField_gaurd').removeAttr('data-error');
    }
});
$("#seeAnotherField").trigger("change");





$("#seeAnotherField1").change(function() {
  if ($(this).val() == "1") {
    $('#otherFieldDiv1').show();
    $('#otherField').attr('required', '');
    $('#otherField').attr('data-error', 'This field is required.');
  } else {
    $('#otherFieldDiv1').hide();
    $('#otherField').removeAttr('required');
    $('#otherField').removeAttr('data-error');
  }
});
$("#seeAnotherField").trigger("change");





function basement() {
            var basYes = document.getElementById("basYes");
            var dvbas = document.getElementById("dvbas");
     
            dvbas.style.display = basYes.checked ? "block" : "none";
   
}
      


function meterroom() {
            var meterYes = document.getElementById("meterYes");
            var meterbas = document.getElementById("meterbas");
            meterbas.style.display = meterYes.checked ? "block" : "none";
       
}

function watertank() {
            var tankYes = document.getElementById("tankYes");
            var dvtank = document.getElementById("dvtank");
            dvtank.style.display = tankYes.checked ? "block" : "none";
       
}


function inverter() {
            var iYes = document.getElementById("iYes");
            var dvinverter = document.getElementById("dvinverter");
            dvinverter.style.display = iYes.checked ? "block" : "none";
       
}


function office() {
            var societyoffice1 = document.getElementById("societyoffice1");
            var dvoffice = document.getElementById("dvoffice");
            dvoffice.style.display = societyoffice1.checked ? "block" : "none";
       
}


function common() {
            var commonarea1 = document.getElementById("commonarea1");
            var dvcommonarea = document.getElementById("dvcommonarea");
            dvcommonarea.style.display = commonarea1.checked ? "block" : "none";
       
}


function cctv_camera() {
            var cctv1 = document.getElementById("cctv1");
            var dvcamera = document.getElementById("dvcamera");
            dvcamera.style.display = cctv1.checked ? "block" : "none";
       
}


function firesystem() {
            var fire1 = document.getElementById("fire1");
            var dvfire = document.getElementById("dvfire");
            dvfire.style.display = fire1.checked ? "block" : "none";
       
}


function security() {
            var physicalsecurity1 = document.getElementById("physicalsecurity1");
            var dvgaurds = document.getElementById("dvgaurds");
            dvgaurds.style.display = physicalsecurity1.checked ? "block" : "none";
       
}


function club() {
            var clubhouse1 = document.getElementById("clubhouse1");
            var dvclub = document.getElementById("dvclub");
            dvclub.style.display = clubhouse1.checked ? "block" : "none";
       
}

function pool() {
            var swimming1 = document.getElementById("swimming1");
            var dvpool = document.getElementById("dvpool");
            dvpool.style.display = swimming1.checked ? "block" : "none";
       
}
//////////////////////////////////TAB///////////////////////////////////////
$.fn.responsiveTabs = function() {
    var container = this;
    container
        .on('show.bs.collapse', '.panel-collapse', function() {
            $(this).addClass('active')
                .siblings('.panel-collapse').removeClass('active').collapse('hide');
            container.find('.nav-tabs a[href="#' + $(this).attr('id') + '"]').parent().addClass('active')
                .siblings().removeClass('active');
        })
        .on('show.bs.tab', '.nav-tabs a', function() {
            $($(this).attr('href')).addClass('in')
                .siblings('.tab-pane').removeClass('in');
        });
};

// Instanciation
$(document).ready(function() {
    $('.responsive-tabs').responsiveTabs();
});