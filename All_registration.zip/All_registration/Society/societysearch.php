<?php
session_start();
include '../databaseconnection/databasesociety.php';
if (isset($_GET['delete'])) {
    $society_delete = societydelete($_GET['delete']);
}

$searchoutput = "";
if (isset($_POST['searchbtn'])) {
    $search_society = $_POST['search_list'];
    $societylist = searchsociety($_SESSION['user'], $search_society);
    if (count($societylist) > 0) {
        foreach ($societylist as $row) {
            $insured = $row["insured"] == 1 ? "Insured" : "Uninsured";
            //
            $basement = $row["basement"] == 1 ? "Yes" : "No";
            $meter_room = $row["meter_room"] == 1 ? "Yes" : "No";
            $water_tank = $row["water_tank"] == 1 ? "Yes" : "No";
            $inverter = $row["inverter"] == 1 ? "Yes" : "No";
            $society_office = $row["society_office"] == 1 ? "Yes" : "No";
            $ac = $row["ac"] == 1 ? "Yes" : "No";
            $water_pumps = $row["water_pumps"] == 1 ? "Yes" : "No";
            $common_areaa = $row["common"] == 1 ? "Yes" : "No";
            $sewage = $row["sewage"] == 1 ? "Yes" : "No";
            $garbage = $row["garbage"] == 1 ? "Yes" : "No";
            //
            $cctv = $row["cctv"] == 1 ? "Yes" : "No";
            $fire_system = $row["fire_system"] == 1 ? "Yes" : "No";
            $physical_security = $row["physical_security"] == 1 ? "Yes" : "No";
//
            $audited = $row["audited"] == 1 ? "Yes" : "No";
            $club = $row["club"] == 1 ? "Yes" : "No";
            $swimming = $row["swimming"] == 1 ? "Yes" : "No";
            //
            $searchoutput = $searchoutput . "<tr><td>"
                    . $row["name"] . "</td>" .
                    "<td>" . $row["address"] . "</td>" .
                    "<td>" . $row["email"] . "</td>" .
                    "<td>" . $row["alternateemail"] . "</td>" .
                    "<td>" . $row["manager"] . "</td>" .
                    "<td>" . $row["manager_contact"] . "</td>" .
                    "<td>" . $row["chairman"] . "</td>" .
                    "<td>" . $row["chairman_contact"] . "</td>" .
                    "<td>" . $row["secretary"] . "</td>" .
                    "<td>" . $row["secretary_contact"] . "</td>" .
                    "<td>" . $row["treasurer"] . "</td>" .
                    "<td>" . $row["treasurer_contact"] . "</td>" .
                    //
                    "<td>" . $insured . "</td>" .
                    //
                    "<td>" . $row["existing_insure"] . "</td>" .
                    "<td>" . $row["policy_name"] . "</td>" .
                    "<td>" . $row["expiry_date"] . "</td>" .
                    "<td>" . $row["agent"] . "</td>" .
                    //17
                    "<td>" . $row["expiring_sum"] . "</td>" .
                    "<td>" . $row["area_mtft"] . "</td>" .
                    "<td>" . $row["no_floor"] . "</td>" .
                    "<td>" . $row["no_wing"] . "</td>" .
                    "<td>" . $row["no_flat"] . "</td>" .
                    "<td>" . $row["totalbuild_area"] . "</td>" .
                    "<td>" . $row["area_perflat"] . "</td>" .
                    //
                    "<td>" . $basement . "</td>" .
                    "<td>" . $row["basement_area"] . "</td>" .
                    "<td>" . $meter_room . "</td>" .
                    "<td>" . $row["meter_area"] . "</td>" .
                    "<td>" . $water_tank . "</td>" .
                    "<td>" . $row["water_tankcapacity"] . "</td>" .
                    "<td>" . $inverter . "</td>" .
                    "<td>" . $row["inverter_time"] . "</td>" .
                    "<td>" . $society_office . "</td>" .
                    "<td>" . $row["society_officearea"] . "</td>" .
                    "<td>" . $ac . "</td>" .
                    "<td>" . $water_pumps . "</td>" .
                    "<td>" . $common_areaa . "</td>" .
                    "<td>" . $row["common_area"] . "</td>" .
                    "<td>" . $sewage . "</td>" .
                    "<td>" . $garbage . "</td>" .
                    //
                    "<td>" . $row["remark"] . "</td>" .
                    //
                    "<td>" . $cctv . "</td>" .
                    "<td>" . $row["cctv_total"] . "</td>" .
                    "<td>" . $fire_system . "</td>" .
                    "<td>" . $row["fire_systemtotal"] . "</td>" .
                    "<td>" . $physical_security . "</td>" .
                    //
                    "<td>" . $row["no_gaurds"] . "</td>" .
                    //
                    "<td>" . $audited . "</td>" .
                    //
                    "<td>" . $row["type"] . "</td>" .
                    "<td>" . $row["security_remark"] . "</td>" .
                    "<td>" . $row["power_back"] . "</td>" .
                    //
                    "<td>" . $club . "</td>" .
                    "<td>" . $row["club_area"] . "</td>" .
                    "<td>" . $swimming . "</td>" .
                    "<td>" . $row["swimming_area"] . "</td>" .
                    //
                    "<td>" . $row["inhouse"] . "</td>" .
                    "<td>" . $row["amenities_area"] . "</td>" .
                    "<td>" . $row["overall_remark"] . "</td>" .
                    "<td><a class='btn btn-danger btn-sm' href='societysearch.php?delete=" . $row["id"] . "'>Delete</a><br><br><a class='btn btn-info btn-sm' href='societyupdate.php?edit=" . $row["id"] . "'>Update</a> </td>"
                    . "</tr>";
        }
    }
}
if (isset($_SESSION['user']) && $_SESSION['user'] != "") {

} else {
    header("Location:../login/login.php");
}
?>

<?php include './header_soc.php'; ?>

<section id="contents" style="background-image: url(../Insurance/asfalt-dark.png)">
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <i class="fa fa-align-right"></i>
                </button>
                <a class="navbar-brand" href="#">my<span class="main-color">Dashboard</span></a>
            </div>
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav" style="margin-top: 10px;">
                    <li><a href="#"><i data-show="show-side-navigation1" class="fa fa-bars show-side-btn"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <br>
    <div class="container my-5 text-center" >
        <div class="row">
            <div class="col-md-12">
                <Form method="POST">
                    <div class="form-group">
                        <input type="text" name="search_list" class="form-control" placeholder="serach here" >
                    </div>
                    <div class="form-group">
                        <input type="submit"name="searchbtn" value="Search" class="btn btn-success center-block" />
                    </div>
                </Form>
                <div class="table-responsive">
                    <table border = "2" class = "table text-capitalize " style = "color: white;font-size:12px">
                        <tr>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Email</th>
                            <th>Alternat Email</th>
                            <th>Manager</th>
                            <th>Manager Contact</th>
                            <th>Chairman</th>
                            <th>Chairman Contact</th>
                            <th>secretary</th>
                            <th>secretary Contact</th>
                            <th>Treasurer</th>
                            <th>Treasurer Contact</th>
                            <th>Insured/Uninsured</th>
                            <th>Existing insure</th>
                            <th>policy Name</th>
                            <th>Expiry Date</th>
                            <th>Agent/Broker</th>
                            <th>Expiring_sum</th>
                            <th>Area per mt/ft</th>
                            <th>No floor</th>
                            <th>No wing</th>
                            <th>No flat</th>
                            <th>Total Build Area</th>
                            <th>Area per flat</th>
                            <th>Basement</th>
                            <th>Basement Area</th>
                            <th>Meter room</th>
                            <th>Meter Area</th>
                            <th>Water tank</th>
                            <th>Water tank capacity</th>
                            <th>Inverter</th>
                            <th>Inverter Hrs</th>
                            <th>Society office</th>
                            <th>Society office Area</th>
                            <th>AC's</th>
                            <th>Water pumps</th>
                            <th>Common</th>
                            <th>Common Area</th>
                            <th>Sewage</th>
                            <th>Garbage</th>
                            <th>Remark</th>
                            <th>CCTV Camera</th>
                            <th>CCTV Total</th>
                            <th>Fire Fight System</th>
                            <th>Fire Total</th>
                            <th>Physical Security</th>
                            <th>No Gaurds</th>
                            <th>Audited</th>
                            <th>Type</th>
                            <th>Security Remark</th>
                            <th>Power Back</th>
                            <th>Club/GYM</th>
                            <th>Club/GYM Area</th>
                            <th>Swimming</th>
                            <th>Swimming Area</th>
                            <th>Inhouse</th>
                            <th>Amenities Area</th>
                            <th>Overall  Remark</th>
                            <th>Action</th>
                        </tr>
                        <tbody>
                            <?php
                            echo $searchoutput;
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<br />


<?php
include './footer_soc.php';
?>


