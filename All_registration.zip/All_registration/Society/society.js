    $(document).ready(function () {

        $('#btn_basic_details').click(function () {
            var error_society='';
            var error_email = '';
            var error_address = '';
           // var error_password = '';
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

           if ($.trim($('#socname').val()).length == 0)
            {
                error_society = 'Society Name is required';
                $('#error_society').text(error_society);
                $('#socname').addClass('has-error');
            } else
            {
               error_society = '';
                $('#error_society').text(error_society);
                $('#socname').removeClass('has-error');
            }

           if ($.trim($('#address').val()).length == 0)
            {
                error_address = 'Address is required';
                $('#error_address').text(error_address);
                $('#address').addClass('has-error');
            } else
            {
                error_address = '';
                $('#error_address').text(error_address);
                $('#address').removeClass('has-error');
            }
            


//            if ($.trim($('#email').val()).length == 0)
//            {
//                error_email = 'Email is required';
//                $('#error_email').text(error_email);
//                $('#email').addClass('has-error');
//            } else
//            {
//                if (!filter.test($('#email').val()))
//                {
//                    error_email = 'Invalid Email';
//                    $('#error_email').text(error_email);
//                    $('#email').addClass('has-error');
//                } else
//                {
//                    error_email = '';
//                    $('#error_email').text(error_email);
//                    $('#email').removeClass('has-error');
//                }
//            }

            if (error_address != ''|| error_society!='')
            {
                return false;
            } else
            {
                $('#list_basic_details').removeClass('active active_tab1');
                $('#list_basic_details').removeAttr('href data-toggle');
                $('#basic_details').removeClass('active');
                $('#list_basic_details').addClass('inactive_tab1');
                $('#list_member_details').removeClass('inactive_tab1');
                $('#list_member_details').addClass('active_tab1 active');
                $('#list_member_details').attr('href', '#member_details');
                $('#list_member_details').attr('data-toggle', 'tab');
                $('#member_details').addClass('active in');
            }
        });

        $('#previous_btn_member_details').click(function () {
            $('#list_member_details').removeClass('active active_tab1');
            $('#list_member_details').removeAttr('href data-toggle');
            $('#member_details').removeClass('active in');
            $('#list_member_details').addClass('inactive_tab1');
            $('#list_basic_details').removeClass('inactive_tab1');
            $('#list_basic_details').addClass('active_tab1 active');
            $('#list_basic_details').attr('href', '#basic_details');
            $('#list_basic_details').attr('data-toggle', 'tab');
            $('#basic_details').addClass('active in');
        });
/////////////////////-------------////////////////////////
        $('#btn_member_details').click(function () {
//            var error_manager_email = '';
//            var error_manager_contact = '';
           // var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            
            
//             if ($.trim($('#manager_email').val()).length == 0)
//            {
//               error_manager_email = 'Email is required';
//                $('#error_manager_email').text(error_manager_email);
//                $('#manager_email').addClass('has-error');
//            } else
//            {
//                if (!filter.test($('#manager_email').val()))
//                {
//                    error_manager_email = 'Invalid Email';
//                    $('#error_manager_email').text(error_manager_email);
//                    $('#manager_email').addClass('has-error');
//                } else
//                {
//                    error_manager_email = '';
//                    $('#error_manager_email').text(error_manager_email);
//                    $('#manager_email').removeClass('has-error');
//                }
//            }


//            if ($.trim($('#manager_contact').val()).length == 0)
//            {
//               error_manager_contact = '*required';
//                $('#error_manager_contact').text(error_manager_contact);
//                $('#manager_contact').addClass('has-error');
//            } else
//            {
//                error_manager_contact = '';
//                $('#error_manager_contact').text(error_manager_contact);
//                $('#manager_contact').removeClass('has-error');
//            }


 

//            if (error_manager_email != '' || error_manager_contact != '')
//            {
//                return false;
//            } else{
//            
//            }
//            
            
            
            
                $('#list_member_details').removeClass('active active_tab1');
                $('#list_member_details').removeAttr('href data-toggle');
                $('#member_details').removeClass('active');
                $('#list_member_details').addClass('inactive_tab1');
                $('#list_insured_details').removeClass('inactive_tab1');
                $('#list_insured_details').addClass('active_tab1 active');
                $('#list_insured_details').attr('href', '#insured_details');
                $('#list_insured_details').attr('data-toggle', 'tab');
                $('#insured_details').addClass('active in');
            
        });

        $('#previous_btn_insured_details').click(function () {
            $('#list_insured_details').removeClass('active active_tab1');
            $('#list_contact_details').removeAttr('href data-toggle');
            $('#insured_details').removeClass('active in');
            $('#list_insured_details').addClass('inactive_tab1');
            $('#list_member_details').removeClass('inactive_tab1');
            $('#list_member_details').addClass('active_tab1 active');
            $('#list_member_details').attr('href', '#member_details');
            $('#list_member_details').attr('data-toggle', 'tab');
            $('#member_details').addClass('active in');
        });
/////////////////////-------------////////////////////////
        $('#btn_insured_details').click(function () {

           // var error_insure='';
             
             
//              if ($.trim($('#otherField1').val()).length == 0)
//            {
//                error_insure = 'Society Name is required';
//                $('#error_insure').text(error_insure);
//                $('#otherField1').addClass('has-error');
//            } else
//            {
//              error_insure = '';
//                $('#error_insure').text(error_insure);
//                $('#otherField1').removeClass('has-error');
//            }
            

//              if (error_insure != '')
//            {
//                return false;
//            } else
//            {
//            }

                $('#btn_insured_details').attr("disabled", "disabled");
                $(document).css('cursor', 'prgress');
                $("#register_form").submit();
        });

    });
//////////////////////////////////////////////////////////////////////////////////
