<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            .btn3d {
                transition:all .08s linear;
                position:relative;
                outline:medium none;
                -moz-outline-style:none;
                border:0px;
                margin-right:10px;
                margin-top:15px;
            }
            .btn3d:focus {
                outline:medium none;
                -moz-outline-style:none;
            }
            .btn3d:active {
                top:9px;
            }
            .btn-default {
                box-shadow:0 0 0 1px #ebebeb inset, 0 0 0 2px rgba(255,255,255,0.15) inset, 0 8px 0 0 #adadad, 0 8px 0 1px rgba(0,0,0,0.4), 0 8px 8px 1px rgba(0,0,0,0.5);
                background-color:#fff;
            }
        </style>
    </head>
    <body style="background: sienna">

        <button type="button" class="btn3d btn btn-default btn-lg"><span class="glyphicon glyphicon-download-alt"></span> Default</button>

    </body>
</html>