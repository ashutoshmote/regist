<?php

include '../databaseconnection/databasesociety.php';
session_start();
$output = '';


if (isset($_POST["export_excel"])) {

    $sqlexport = insuranceshow($_SESSION['user']);
    if ($sqlexport > 0) {
        $output .= '<table class="table"  border="1" style="font-size:18px;">
                      <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>mobile</th>
                      <th>email</th>
                      <th>address</th>
                      <th>ifinsured</th>
                      <th>homeloan</th>
                      <th>homedate</th>
                      <th>carloan</th>
                      <th>cardate</th>
                      <th>healthloan</th>
                      <th>healthdate</th>
                      <th>personlloan</th>
                      <th>personaldate</th>
                      <th>dob</th>
                      <th>occupation</th>
                      <th>loantype</th>
                      <th>ifbusiness</th>
                      <th>companyname</th>
                      <th>noemploye</th>
                      <th>typebusiness</th>
                      <th>anyinsurance</th>
                      <th>officeloan</th>
                      <th>officedate</th>
                      <th>factoryloan</th>
                      <th>factorydate</th>
                      <th>gmcloan</th>
                      <th>gmcdate</th>
                      <th>wcloan</th>
                      <th>wcdate</th>
                      <th>liabilityloan</th>
                      <th>liabilitydate</th>
                      <th>anyother</th>
                      <th>specify</th>
                      </tr> ';
        foreach ($sqlexport as $row) {
            $occupation = $row["occupation"] == 1 ? "Service" : "Business";
            $ifinsured = $row["ifinsured"] == 1 ? "Yes" : "No";
            $ifbusiness = $row["ifbusiness"] == 1 ? "Yes" : "No";
            $home = $row["homeloan"] == 1 ? "Yes" : "No";
            $car = $row["carloan"] == 1 ? "Yes" : "No";
            $health = $row["healthloan"] == 1 ? "Yes" : "No";
            $personl = $row["personlloan"] == 1 ? "Yes" : "No";
            $TypeInsurance = $row["anyinsurance"] == 1 ? "Yes" : "No";
            $Office = $row["officeloan"] == 1 ? "Yes" : "No";
            $factory = $row["factoryloan"] == 1 ? "Yes" : "No";
            $gmc = $row["gmcloan"] == 1 ? "Yes" : "No";
            $wc = $row["wcloan"] == 1 ? "Yes" : "No";
            $Liability = $row["liabilityloan"] == 1 ? "Yes" : "No";
            $Anyother = $row["anyother"] == 1 ? "Yes" : "No";

            $output .= '<tr>
                      <td>' . $row["id"] . '</td>
                      <td>' . $row["name"] . '</td>
                      <td>' . $row["mobile"] . '</td>
                      <td>' . $row["email"] . '</td>
                      <td>' . $row["address"] . '</td>
                      <td>' . $ifinsured . '</td>
                      <td>' . $home . '</td>
                      <td>' . $row["homedate"] . '</td>
                      <td>' . $car . '</td>
                      <td>' . $row["cardate"] . '</td>
                      <td>' . $health . '</td>
                      <td>' . $row["healthdate"] . '</td>
                      <td>' . $personl . '</td>
                      <td>' . $row["personaldate"] . '</td>
                      <td>' . $row["dob"] . '</td>
                      <td>' . $occupation . '</td>
                      <td>' . $row["loantype"] . '</td>
                      <td>' . $ifbusiness . '</td>
                      <td>' . $row["companyname"] . '</td>
                      <td>' . $row["noemploye"] . '</td>
                      <td>' . $row["typebusiness"] . '</td>
                      <td>' . $TypeInsurance . '</td>
                      <td>' . $Office . '</td>
                      <td>' . $row["officedate"] . '</td>
                      <td>' . $factory . '</td>
                      <td>' . $row["factorydate"] . '</td>
                      <td>' . $gmc . '</td>
                      <td>' . $row["gmcdate"] . '</td>
                      <td>' . $wc . '</td>
                      <td>' . $row["wcdate"] . '</td>
                      <td>' . $Liability . '</td>
                      <td>' . $row["liabilitydate"] . '</td>
                      <td>' . $Anyother . '</td>
                      <td>' . $row["specify"] . '</td>
            </tr>';
        }
        $output .= '</table>';
        @header('Content-type:application/vnd.ms-excel');
        @header('Content-Disposition: attachment; filename=insurance.xls');

        echo $output;
    }
}
?>