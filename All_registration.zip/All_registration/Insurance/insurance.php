<?php
session_start();
include '../databaseconnection/databasesociety.php';

$insuranceoutput = "";
if (isset($_REQUEST['insurancebtn'])) {
    if (!empty($_POST['ins_name'])) {

        $name = $_POST['ins_name'];
        $mobile = $_POST['ins_contact'];
        $email = $_POST['ins_email'];
        $address = $_POST['ins_address'];


        $insured = $_POST['ifinsured'];
        $home_loan = $_POST['homeloan'];
        $home_date = $_POST['homedate'];
        $car_loan = $_POST['carloan'];
        $car_date = $_POST['cardate'];
        $health_loan = $_POST['healthloan'];
        $health_date = $_POST['healthdate'];
        $personal_loan = $_POST['personalloan'];
        $personal_date = $_POST['personaldate'];

        $dob = $_POST['ins_dob'];
        $occupation = $_POST['occupation'];
        $loan_type = $_POST['loantype'];
        $ifbusiness = $_POST['ifbusiness'];
        $company_name = $_POST['company_name'];
        $no_employes = $_POST['no_employes'];
        $type_business = $_POST['type_business'];

        $type_insurance = $_POST['type_insurance'];

        $office_loan = $_POST['officeloan'];
        $office_date = $_POST['officedate'];
        $factory_loan = $_POST['factoryloan'];
        $factory_date = $_POST['factorydate'];
        $gmc_loan = $_POST['gmcloan'];
        $gmc_date = $_POST['gmcdate'];
        $wc_loan = $_POST['wcloan'];
        $wc_date = $_POST['wcdate'];
        $liability_loan = $_POST['liabilityloan'];
        $liability_date = $_POST['liabilitydate'];
        $any_other = $_POST['anyother'];
        $specify = $_POST['specify'];
        $login_id = $_POST['ins_loginid'];
        $login_uname = $_POST['ins_loginuser'];


//        $insresult = insuranceinsert($name, $mobile, $email, $address, $dob, $occupation, $loan_type, $ifbusiness, $company_name, $no_employes, $type_business, $type_insurance);
        $insresult = insuranceinsert($name, $mobile, $email, $address, $insured, $home_loan, $home_date, $car_loan, $car_date, $health_loan, $health_date, $personal_loan, $personal_date, $dob, $occupation, $loan_type, $ifbusiness, $company_name, $no_employes, $type_business, $type_insurance, $office_loan, $office_date, $factory_loan, $factory_date, $gmc_loan, $gmc_date, $wc_loan, $wc_date, $liability_loan, $liability_date, $any_other, $specify, $login_id, $login_uname);

        if ($insresult > 0) {
            header("Location:insurance.php");
            exit();
        } else {
            echo "<div class='alert alert-danger'>" . " <strong>Unsuccess!</strong> " . "</div>";
        }
    }
}
$loginid_list = getloginid($_SESSION['user']);
if (isset($_SESSION['user']) && $_SESSION['user'] != "") {

} else {
    header("Location:../login/login.php");
}
?>
<?php
include './header.php';
?>
<section id="contents" style="color: white;background-image: url(asfalt-dark.png)">
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <i class="fa fa-align-right"></i>
                </button>
                <a class="navbar-brand" href="#">my<span class="main-color">Dashboard</span></a>
            </div>
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav" style="margin-top: 10px;">
                    <li><a href="#"><i data-show="show-side-navigation1" class="fa fa-bars show-side-btn"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="row" style="margin: 20px;">
            <div class="col-md-12">
                <form method="POST">
                    <div class="form-group">
                        <div class="row align-items-center">
                            <div class="col mt-4">
                                <h5>UserID:</h5>
                                <input type="text" class="form-control" value="<?php echo $loginid_list[0]['login_id']; ?>" placeholder="Enter Name" onkeyup="letter(this)" name="ins_loginid" required="">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center">
                            <div class="col mt-4">
                                <h5>User Name:</h5>
                                <input type="text" class="form-control" value="<?php echo $loginid_list[0]['login_name']; ?>" placeholder="Enter Name" onkeyup="letter(this)" name="ins_loginuser" required="">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center">
                            <div class="col mt-4">
                                <h5>Name:</h5>
                                <input type="text" class="form-control" placeholder="Enter Name" onkeyup="letter(this)" name="ins_name" required="">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center">
                            <div class="col mt-4">
                                <h5>Mobile No:</h5>
                                <input type="text" class="form-control" placeholder="Enter Contact Number" onkeyup="numberonly(this)" name="ins_contact" required="">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center">
                            <div class="col mt-4">
                                <h5>Eamil:</h5>
                                <input type="text" class="form-control" placeholder="Enter Eamil"  name="ins_email" required="">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center">
                            <div class="col mt-4">
                                <h5>Address:</h5>
                                <textarea class="form-control" rows="5" onkeyup="alphnumeric(this)" name="ins_address" ></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row align-items-center mt-4" id="refer" style="font-size: 19px;font-weight:600">
                            <div class="col">
                                <label for="seeAnotherFieldinsured">If Insured:</label>
                                <select  class="form-control" id="seeAnotherFieldinsured" name="ifinsured" required style="font-weight: bold">
                                    <option value="">Choose Yes or No</option>
                                    <option value="0">No</option>
                                    <option value="1">Yes</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group mt-4" id="otherFieldGroupDiv1" style="font-size: 19px;font-weight:600">

                        <div class="container mt-5">
                            <div class="row align-items-center">
                                <div class="form-group">
                                    <div class="col-md-6">
                                        <h5>1)Home Loan</h5>
                                        <label for="hYes">
                                            <input type="radio" id="hYes" name="homeloan" value="1" onclick="ShowHideDiv()" />
                                            Yes
                                        </label>
                                        <label for="hNo">
                                            <input type="radio" id="hNo" name="homeloan" value="0" checked="" onclick="ShowHideDiv()" />
                                            No
                                        </label>

                                        <div id="dv1" style="display: none">
                                            <h5> Expiry Date:</h5>
                                            <input type="date" name="homedate" class="" id="txthomedate" style="color: black" />
                                        </div>
                                    </div></div>




                                <div class="col-md-6">
                                    <h5>2)Car Loan</h5>
                                    <label for="cYes">
                                        <input type="radio" id="cYes" name="carloan" value="1" onclick="ShowHideDiv1()" />
                                        Yes
                                    </label>
                                    <label for="cNo">
                                        <input type="radio" id="cNo" name="carloan" value="0"  checked="" onclick="ShowHideDiv1()" />
                                        No
                                    </label>
                                    <div class="form-group">
                                        <div id="dvCar" style="display: none">
                                            <h5> Expiry Date:</h5>
                                            <input type="date" name="cardate" class="" id="txtcardate" style="color: black" />
                                        </div></div>
                                </div>



                            </div>
                            <!--////////////-->



                            <div class="row align-items-center mt-4">

                                <div class="col-md-6">
                                    <h5>3)Health Loan</h5>
                                    <label for="heYes">
                                        <input type="radio" id="heYes" name="healthloan" value="1" onclick="ShowHideDiv3()" />
                                        Yes
                                    </label>
                                    <label for="heNo">
                                        <input type="radio" id="heNo" name="healthloan" value="0" checked="" onclick="ShowHideDiv3()" />
                                        No
                                    </label>

                                    <div id="dvhelath" style="display: none">
                                        <h5> Expiry Date:</h5>
                                        <input type="date" name="healthdate" class="" id="txthealthdate" style="color: black"  />
                                    </div>
                                </div>




                                <div class="col-md-6">
                                    <h5>4)Persnol Loan</h5>
                                    <label for="pYes">
                                        <input type="radio" id="pYes" name="personalloan" value="1" onclick="ShowHideDiv_persnol()" />
                                        Yes
                                    </label>
                                    <label for="pNo">
                                        <input type="radio" id="pNo" name="personalloan" value="0" checked="" onclick="ShowHideDiv_persnol()" />
                                        No
                                    </label>

                                    <div id="dvper" style="display: none">
                                        <h5> Expiry Date:</h5>
                                        <input type="date" name="personaldate" class="" id="txtpersnoldate" style="color: black"  />
                                    </div>
                                </div>



                            </div>

                        </div>


                    </div>

                    <div class="form-group">
                        <div class="row align-items-center">
                            <div class="col mt-4">
                                <h5>Date Of Birth:</h5>
                                <input type="date" class="form-control" placeholder="Enter DOB"  name="ins_dob" required="">
                            </div>
                        </div>
                    </div>




                    <div class="form-group">
                        <div class="row align-items-center mt-4" id="radiobtn">
                            <div class="col">
                                <h5>Occupation: </h5>
                                <div class="occ" style="font-size:18px;font-weight: 500">
                                    <div class="custom-control radio-inline ">
                                        <input type="radio" class="custom-control-input" id="no" name="occupation" value="0" checked="" required>
                                        <label class="custom-control-label" for="no">Service</label>
                                    </div>
                                    <div class="custom-control radio-inline">
                                        <input type="radio" class="custom-control-input" id="yes" name="occupation" value="1" required>
                                        <label class="custom-control-label" for="yes">Business</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="row align-items-center mt-4">
                            <div class="col">
                                <div class="form-group" style="font-size:20px;font-weight: 500">
                                    <label for="sel1">Loans Type:</label>
                                    <select class="form-control" id="sel1" name="loantype" style="font-size:17px;font-weight: 600">
                                        <option>Choose One</option>
                                        <option value="Home Loan">Home Loan</option>
                                        <option value="Car Loan">Car Loan</option>
                                        <option value="Personal Loan">Personal Loan</option>
                                        <option value="Other Loan">Other Loan</option>
                                    </select></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row align-items-center mt-4" style="font-size: 19px;font-weight:600">
                            <div class="col">
                                <label for="seeAnotherFieldGroup">If Business:</label>
                                <select  class="form-control" id="seeAnotherFieldGroup" name="ifbusiness" required style="font-weight: bold">
                                    <option value="">Choose Yes or No</option>
                                    <option value="0">No</option>
                                    <option value="1">Yes</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mt-4" id="otherFieldGroupDiv" style="font-size: 19px;font-weight:600">
                        <div class="row">
                            <div class="col-12">

                                <label for="otherField1">1)Company Name</label>
                                <input type="text" class="form-control w-100" onkeyup="alphnumeric(this)" name="company_name" id="otherField1">
                            </div>
                            <div class="col-12 mt-4">
                                <label for="otherField2">2)No Of Employes</label>
                                <input type="text" class="form-control w-100" onkeyup="numberonly(this)" name="no_employes" id="otherField2">
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-12">
                                <label for="otherField1">3)Type of Business</label>
                                <input type="text" class="form-control w-100" onkeyup="letter(this)" name="type_business" id="otherField3">
                            </div>

                        </div>


                        <!--/////////////------IF Insurance Any------///////////////-->
                        <div class="row align-items-center mt-4" style="font-size: 19px;font-weight:600">
                            <div class="col">
                                <label for="seeAnotherFieldinsurance">4)If Any Insurance:</label>
                                <select  class="form-control" id="seeAnotherFieldinsurance" name="type_insurance" style="font-weight: bold">
                                    <option value="0">No</option>
                                    <option value="1">Yes</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group mt-4" id="otherFieldGroupDiv2" style="font-size: 19px;font-weight:600">

                            <div class="container mt-5">
                                <div class="row align-items-center">

                                    <div class="col-md-6">
                                        <h5>i)Office Insurance</h5>
                                        <label for="oYes">
                                            <input type="radio" id="oYes" name="officeloan" value="1" onclick="office()" />
                                            Yes
                                        </label>
                                        <label for="oNo">
                                            <input type="radio" id="oNo" name="officeloan" value="0" checked="" onclick="office()" />
                                            No
                                        </label>

                                        <div id="dvo" style="display: none">
                                            Expiry Date:
                                            <input type="date" name="officedate" class=""/>
                                        </div>
                                    </div>




                                    <div class="col-md-6">
                                        <h5>ii)Factory Insurance</h5>
                                        <label for="faYes">
                                            <input type="radio" id="faYes" name="factoryloan" value="1" onclick="factory()" />
                                            Yes
                                        </label>
                                        <label for="faNo">
                                            <input type="radio" id="cNo" name="factoryloan" value="0" checked="" onclick="factory()" />
                                            No
                                        </label>

                                        <div id="dvfa" style="display: none">
                                            Expiry Date:
                                            <input type="date" name="factorydate" class="" />
                                        </div>
                                    </div>



                                </div>
                                <!--////////////-->



                                <div class="row align-items-center mt-4">

                                    <div class="col-md-6">
                                        <h5>iii)GMC/GPA</h5>
                                        <label for="gYes">
                                            <input type="radio" id="gYes" name="gmcloan" value="1" onclick="ShowHideDivgmc()" />
                                            Yes
                                        </label>
                                        <label for="gNo">
                                            <input type="radio" id="gNo" name="gmcloan" value="0" checked="" onclick="ShowHideDivgmc()" />
                                            No
                                        </label>

                                        <div id="dvg" style="display: none">
                                            Expiry Date:
                                            <input type="date" name="gmcdate" class=""  />
                                        </div>
                                    </div>




                                    <div class="col-md-6">
                                        <h5>iv)WC</h5>
                                        <label for="wYes">
                                            <input type="radio" id="wYes" name="wcloan" value="1" onclick="ShowHideDiv_wc()" />
                                            Yes
                                        </label>
                                        <label for="wNo">
                                            <input type="radio" id="wNo" name="wcloan" value="0" checked="" onclick="ShowHideDiv_wc()" />
                                            No
                                        </label>

                                        <div id="dvwc" style="display: none">
                                            Expiry Date:
                                            <input type="date" name="wcdate" class=""  />
                                        </div>
                                    </div>



                                </div>



                                <div class="row align-items-center mt-4">

                                    <div class="col-md-6">
                                        <h5>v)Liability</h5>
                                        <label for="lYes">
                                            <input type="radio" id="lYes" name="liabilityloan" value="1" onclick="ShowHideDivlia()" />
                                            Yes
                                        </label>
                                        <label for="lNo">
                                            <input type="radio" id="lNo" name="liabilityloan" value="0" checked="" onclick="ShowHideDivlia()" />
                                            No
                                        </label>

                                        <div id="dvlia" style="display: none">
                                            Expiry Date:
                                            <input type="date" name="liabilitydate" class=""  />
                                        </div>
                                    </div>




                                    <div class="col-md-6">
                                        <h5>vi)Any Other</h5>
                                        <label for="anyYes">
                                            <input type="radio" id="anyYes" name="anyother" value="1" onclick="ShowHideDiv_any()" />
                                            Yes
                                        </label>
                                        <label for="anyNo">
                                            <input type="radio" id="anyNo" name="anyother" value="0" checked="" onclick="ShowHideDiv_any()" />
                                            No
                                        </label>

                                        <div id="dvany" style="display: none">
                                            Please Specify:
                                            <input type="text" name="specify" placeholder="please specify" class=""  />
                                        </div>
                                    </div>



                                </div>




                            </div>
                        </div>

                    </div>

                    <div class="form-group" style="margin-top:50px">
                        <div class="text-center mb-5">
                            <!--                                    <button class="button" name="insurancebtn"  id="submitbtn">
                                                                    <i class="fa fa-send-o fa-lg"></i> SUBMIT</button>-->

                            <button  name="insurancebtn"  id="submitbtn"><span>SUBMIT</span></button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</section>
<?php include './footer.php'; ?>