$("#seeAnotherField").change(function() {
  if ($(this).val() == "1") {
    $('#otherFieldDiv').show();
    $('#otherField').attr('required', '');
    $('#otherField').attr('data-error', 'This field is required.');
  } else {
    $('#otherFieldDiv').hide();
    $('#otherField').removeAttr('required');
    $('#otherField').removeAttr('data-error');
  }
});
$("#seeAnotherField").trigger("change");

$("#seeAnotherFieldGroup").change(function() {
  if ($(this).val() == "1") {
    $('#otherFieldGroupDiv').show();
    $('#otherField1').attr('required', '');
    $('#otherField1').attr('data-error', 'This field is required.');
    $('#otherField2').attr('required', '');
    $('#otherField2').attr('data-error', 'This field is required.');
  } else {
    $('#otherFieldGroupDiv').hide();
    $('#otherField1').removeAttr('required');
    $('#otherField1').removeAttr('data-error');
    $('#otherField2').removeAttr('required');
    $('#otherField2').removeAttr('data-error');
  }
});
$("#seeAnotherFieldGroup").trigger("change");
/////////////////////////////////////////
//insured

$("#seeAnotherFieldinsured").change(function() {
  if ($(this).val() == "1") {
    $('#otherFieldGroupDiv1').show();
    $('#otherField1').attr('required', '');
    $('#otherField1').attr('data-error', 'This field is required.');
    $('#otherField2').attr('required', '');
    $('#otherField2').attr('data-error', 'This field is required.');
  } else {
    $('#otherFieldGroupDiv1').hide();
    $('#otherField1').removeAttr('required');
    $('#otherField1').removeAttr('data-error');
    $('#otherField2').removeAttr('required');
    $('#otherField2').removeAttr('data-error');
  }
});
$("#seeAnotherFieldinsured").trigger("change");
//
/////////////////////////////////////////
//If Insurance
$("#seeAnotherFieldinsurance").change(function() {
  if ($(this).val() == "1") {
    $('#otherFieldGroupDiv2').show();
    $('#otherField1').attr('required', '');
    $('#otherField1').attr('data-error', 'This field is required.');
    $('#otherField2').attr('required', '');
    $('#otherField2').attr('data-error', 'This field is required.');
  } else {
    $('#otherFieldGroupDiv2').hide();
    $('#otherField1').removeAttr('required');
    $('#otherField1').removeAttr('data-error');
    $('#otherField2').removeAttr('required');
    $('#otherField2').removeAttr('data-error');
  }
});
$("#seeAnotherFieldinsurance").trigger("change");

$(documnet).ready(function(){
});

/////////////////////////////////////////
///
function ShowHideDiv() {
            var hYes = document.getElementById("hYes");
            var dv1 = document.getElementById("dv1");
            dv1.style.display = hYes.checked ? "block" : "none";
           
        }
function ShowHideDiv1() {
            var cYes = document.getElementById("cYes");
            var dvCar = document.getElementById("dvCar");
            dvCar.style.display = cYes.checked ? "block" : "none";
}

function ShowHideDiv3() {
            var heYes = document.getElementById("heYes");
            var dvhelath = document.getElementById("dvhelath");
            dvhelath.style.display = heYes.checked ? "block" : "none";
}

function ShowHideDiv_persnol() {
            var pYes = document.getElementById("pYes");
            var dvper = document.getElementById("dvper");
            dvper.style.display = pYes.checked ? "block" : "none";
}
///////////////////////////////////////////////////////////////////////////////
function office() {
            var oYes = document.getElementById("oYes");
            var dvo = document.getElementById("dvo");
            dvo.style.display = oYes.checked ? "block" : "none";
}
function factory() {
            var faYes = document.getElementById("faYes");
            var dvfa = document.getElementById("dvfa");
            dvfa.style.display = faYes.checked ? "block" : "none";
}
function ShowHideDivgmc() {
            var gYes = document.getElementById("gYes");
            var dvg = document.getElementById("dvg");
            dvg.style.display = gYes.checked ? "block" : "none";
}
function ShowHideDiv_wc() {
            var wYes = document.getElementById("wYes");
            var dvwc = document.getElementById("dvwc");
            dvwc.style.display = wYes.checked ? "block" : "none";
}
function ShowHideDivlia() {
            var lYes = document.getElementById("lYes");
            var dvlia = document.getElementById("dvlia");
            dvlia.style.display = lYes.checked ? "block" : "none";
}
function ShowHideDiv_any() {
            var anyYes = document.getElementById("anyYes");
            var dvany = document.getElementById("dvany");
            dvany.style.display = anyYes.checked ? "block" : "none";
}