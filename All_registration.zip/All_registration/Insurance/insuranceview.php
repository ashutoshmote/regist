<?php
session_start();
include '../databaseconnection/databasesociety.php';
$insuranceshowoutput = "";


if (isset($_GET['delete'])) {
    $insurance_delete = insurancedelete($_GET['delete']);
}


$insuranceshowlist = insuranceshow($_SESSION['user']);

if (count($insuranceshowlist) > 0) {
    foreach ($insuranceshowlist as $row) {
        $occupation = $row["occupation"] == 1 ? "Service" : "Business";
        $ifinsured = $row["ifinsured"] == 1 ? "Yes" : "No";
        $ifbusiness = $row["ifbusiness"] == 1 ? "Yes" : "No";
        $home = $row["homeloan"] == 1 ? "Yes" : "No";
        $car = $row["carloan"] == 1 ? "Yes" : "No";
        $health = $row["healthloan"] == 1 ? "Yes" : "No";
        $personl = $row["personlloan"] == 1 ? "Yes" : "No";
        $TypeInsurance = $row["anyinsurance"] == 1 ? "Yes" : "No";
        $Office = $row["officeloan"] == 1 ? "Yes" : "No";
        $factory = $row["factoryloan"] == 1 ? "Yes" : "No";
        $gmc = $row["gmcloan"] == 1 ? "Yes" : "No";
        $wc = $row["wcloan"] == 1 ? "Yes" : "No";
        $Liability = $row["liabilityloan"] == 1 ? "Yes" : "No";
        $Anyother = $row["anyother"] == 1 ? "Yes" : "No";

        $insuranceshowoutput = $insuranceshowoutput . "<tr><td>"
                . $row["name"] . "</td>" .
                "<td>" . $row["mobile"] . "</td>" .
                "<td>" . $row["email"] . "</td>" .
                "<td>" . $row["address"] . "</td>" .
                "<td>" . $ifinsured . "</td>" .
                "<td>" . $home . "</td>" .
                "<td>" . $row["homedate"] . "</td>" .
                "<td>" . $car . "</td>" .
                "<td>" . $row["cardate"] . "</td>" .
                "<td>" . $health . "</td>" .
                "<td>" . $row["healthdate"] . "</td>" .
                "<td>" . $personl . "</td>" .
                "<td>" . $row["personaldate"] . "</td>" .
                "<td>" . $row["dob"] . "</td>" .
                "<td>" . $occupation . "</td>" .
                "<td>" . $row["loantype"] . "</td>" .
                "<td>" . $ifbusiness . "</td>" .
                "<td>" . $row["companyname"] . "</td>" .
                "<td>" . $row["noemploye"] . "</td>" .
                "<td>" . $row["typebusiness"] . "</td>" .
                "<td>" . $TypeInsurance . "</td>" .
                "<td>" . $Office . "</td>" .
                "<td>" . $row["officedate"] . "</td>" .
                "<td>" . $factory . "</td>" .
                "<td>" . $row["factorydate"] . "</td>" .
                "<td>" . $gmc . "</td>" .
                "<td>" . $row["gmcdate"] . "</td>" .
                "<td>" . $wc . "</td>" .
                "<td>" . $row["wcdate"] . "</td>" .
                "<td>" . $Liability . "</td>" .
                "<td>" . $row["liabilitydate"] . "</td>" .
                "<td>" . $Anyother . "</td>" .
                "<td>" . $row["specify"] . "</td>" .
                "<td><a class='btn btn-danger btn-sm' href='insuranceview.php?delete=" . $row["id"] . "'>Delete</a> <br><br> <a class='btn btn-info btn-sm' href='insuranceupdate.php?edit=" . $row["id"] . "'>Update</a> </td>"
                . "</tr>";
    }
}
if (isset($_SESSION['user']) && $_SESSION['user'] != "") {

} else {
    header("Location:../login/login.php");
}
?>
<?php
include './header.php';
?>
<section id="contents">
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <i class="fa fa-align-right"></i>
                </button>
                <a class="navbar-brand" href="#">my<span class="main-color">Dashboard</span></a>
            </div>
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav" style="margin-top: 10px;">
                    <li><a href="#"><i data-show="show-side-navigation1" class="fa fa-bars show-side-btn"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="d-flex flex-column" id="content-wrapper">

        <div class="container-fluid">

            <div class="card shadow-lg o-hidden border-0 my-5">
                <div class="card-body p-0">
                    <div class="live__scroll">

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h4 class="text-dark mb-4">Insurance Form</h4>
                                    </div>
                                    <table border = "2" class = "table text-capitalize " style = " font-size:12px">
                                        <tr>
                                            <th>Name</th>
                                            <th>Contact No</th>
                                            <th>Email</th>
                                            <th>Address</th>
                                            <th>ifinsured</th>
                                            <th>home loan</th>
                                            <th>home date</th>
                                            <th>car loan</th>
                                            <th>car date</th>
                                            <th>health loan</th>
                                            <th>health date</th>
                                            <th>personl loan</th>
                                            <th>personal date</th>
                                            <th>Date of Birth</th>

                                            <th>occupation</th>
                                            <th>loan type</th>
                                            <th>ifbusiness</th>
                                            <th>company name</th>
                                            <th>no employes</th>
                                            <th>type business</th>
                                            <th>type insurance</th>
                                            <th>office loan</th>
                                            <th>office date</th>
                                            <th>factory loan</th>
                                            <th>factory date</th>
                                            <th>gmc loan</th>
                                            <th>gmc date</th>
                                            <th>wc loan</th>
                                            <th>wc date</th>

                                            <th>liability loan</th>
                                            <th>liability date</th>
                                            <th>anyother</th>
                                            <th>Specify</th>
                                            <th>Action</th>


<!--                            <th>Action</th>-->
                                        </tr>
                                        <tbody>
                                            <?php
                                            echo $insuranceshowoutput;
                                            ?>
                                        </tbody>
                                    </table>



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
<?php include './footer.php'; ?>
