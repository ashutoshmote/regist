<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $getlogin_list = getloginid($_SESSION['user']);
        ?>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Dashboard</title>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
            <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />

            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

            <link href="https://fonts.googleapis.com/css?family=Montserrat|Oswald|Roboto|Roboto+Condensed&display=swap" rel="stylesheet">
            <link href="../assets/dash.css" rel="stylesheet" type="text/css"/>
            <link href="company.css" rel="stylesheet" type="text/css"/>
            <style>
                th{
                    background-color:#666
                }
                .btn3d {
                    transition:all .08s linear;
                    position:relative;
                    outline:medium none;
                    -moz-outline-style:none;
                    border:0px;
                    margin-right:10px;
                    margin-top:15px;
                }
                .btn3d:focus {
                    outline:medium none;
                    -moz-outline-style:none;
                }
                .btn3d:active {
                    top:9px;
                }
                .btn-default {
                    box-shadow:0 0 0 1px #ebebeb inset, 0 0 0 2px rgba(255,255,255,0.15) inset, 0 8px 0 0 #adadad, 0 8px 0 1px rgba(0,0,0,0.4), 0 8px 8px 1px rgba(0,0,0,0.5);
                    background-color:#fff;
                }
            </style>
        </head>
        <body style="color:white">
            <aside class="side-nav" id="show-side-navigation1">
                <i class="fa fa-bars close-aside hidden-sm hidden-md hidden-lg" data-close="show-side-navigation1"></i>
                <div class="heading"  style="font-size: 20px;">
                    <i class="fa fa-home fa-fw" aria-hidden="true"></i><a href="#" style="color: white;text-decoration: none"> Registration</a>
                    <div class="info">

                    </div>
                </div>
                <div class="search">

                </div>
                <ul class="categories">
                    <li><i class="fa fa-folder fa-fw"></i><a href="#"><?php echo $getlogin_list[0]['login_name']; ?></a>
                        <ul class="side-nav-dropdown">
                            <form class="collapse-item" action="../login/logout.php" method="POST">
                                <li>
                                    <input type="submit" id="button" name="export_excel" class="btn3d btn btn-warning" value="Logout"/>
                            </form>
                        </ul>

                    </li>
                    <li><i class="fa fa-folder fa-fw"></i><a href="#"> Insurance</a>
                        <ul class="side-nav-dropdown">
                            <li><a href="insurance.php">Insurance Form</a></li>
                            <li><a href="insuranceview.php">Insurance View</a></li>
                            <li><a href="insurancesearch.php">Insurance Serach</a></li>

                            <form class="collapse-item" action="insurance_excel.php" method="POST">
                                <li>
                                    <input type="submit" id="button" name="export_excel" class="btn3d btn btn-success" value="Insurance Excel"/>
                            </form>
                        </ul>

                    </li>

                    <li><i class="fa fa-folder fa-fw"></i><a href="#">Society</a>
                        <ul class="side-nav-dropdown">
                            <li><a href="../Society/society.php">Society Form</a></li>
                            <li><a href="../Society/societyview.php">Society View</a></li>
                            <li><a href="../Society/societysearch.php">Society Search</a></li>
                            <form class="collapse-item" action="../Society/societyexportfile.php" method="POST">
                                <li>
                                    <input type="submit" id="button" name="export_excel" class="btn3d btn btn-success" value="Society Excel"/>
                            </form>
                        </ul>
                    </li>

                </ul>
            </aside>

        </body>
    </html>
