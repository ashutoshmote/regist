<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "societydb";

$conn = new mysqli($servername, $username, $password, $database);

function signupinsert($login_name, $login_email, $login_password, $login_repassword) {
    global $conn;
    $sql_signup = sprintf("INSERT INTO `login_table`(`login_name`, `login_email`, `login_password`,`login_repassword`)
                  VALUES ('%s', '%s', '%s', '%s');", $login_name, $login_email, $login_password, $login_repassword);
    // echo $sql_login;
    $result_signup = $conn->query($sql_signup);
    return $result_signup;
}

function login($email, $password) {
    global $conn;
    $sql_login = "select * from login_table where login_email='" . $email . "' AND login_password='" . $password . "'";
    // $sql_login = "SELECT * FROM `login_table` WHERE login_email='t@gmail.com' AND login_password='1234'";
    $loginresult = $conn->query($sql_login);
    $data = array();
    while ($row = mysqli_fetch_assoc($loginresult)) {
        $data = $row;
    }
    return $data;
}

function getloginid($loginid) {
    global $conn;
    $sql_getlogin = "SELECT `login_id`, `login_name`, `login_email`, `login_password`, `login_repassword` FROM `login_table` WHERE login_id=$loginid";
    $result_getloginid = $conn->query($sql_getlogin);
    $data = array();
    while ($row = mysqli_fetch_assoc($result_getloginid)) {
        $data[] = $row;
    }
    return $data;
}

//function societyinsert($name, $address, $email, $alternateemail, $manager, $manager_contact, $chairman, $chairman_contact, $secretary, $secretary_contact, $treasurer, $treasurer_contact, $insured, $existing_insure, $policy_name, $expiry_date, $agent, $expiring_sum, $area_mtft, $no_floor, $no_wing, $no_flat, $totalbuild_area, $area_perflat, $basement, $basement_area, $meter_room, $meter_area, $water_tank, $water_tankcapacity, $inverter, $inverter_time, $society_office, $society_officearea, $ac, $water_pumps, $common, $common_area, $sewage, $garbage, $remark, $cctv, $cctv_total, $fire_system, $fire_systemtotal, $physical_security, $no_gaurds, $audited, $type, $security_remark, $power_back, $club, $club_area, $swimming, $swimming_area, $inhouse, $amenities_area, $overall_remark) {
//    global $conn;
//    $sql_society = "INSERT INTO `society_tbl`(`name`, `address`, `email`, `alternateemail`, `manager`, `manager_contact`,
//                            `chairman`, `chairman_contact`, `secretary`, `secretary_contact`, `treasurer`,
//                            `treasurer_contact`, `insured`, `existing_insure`, `policy_name`, `expiry_date`,
//                            `agent`, `expiring_sum`, `area_mtft`, `no_floor`, `no_wing`, `no_flat`,
//                            `totalbuild_area`, `area_perflat`, `basement`, `basement_area`, `meter_room`,
//                            `meter_area`, `water_tank`, `water_tankcapacity`, `inverter`, `inverter_time`,
//                            `society_office`, `society_officearea`, `ac`, `water_pumps`, `common`, `common_area`,
//                            `sewage`, `garbage`, `remark`, `cctv`, `cctv_total`, `fire_system`, `fire_systemtotal`,
//                            `physical_security`, `no_gaurds`, `audited`, `type`, `security_remark`, `power_back`, `club`,
//                            `club_area`, `swimming`, `swimming_area`, `inhouse`, `amenities_area`, `overall_remark`)
//                            VALUES
//                            ('$name', '$address', '$email', '$alternateemail', '$manager', '$manager_contact',
//                            '$chairman', '$chairman_contact', '$secretary', '$secretary_contact', '$treasurer',
//                            '$treasurer_contact', $insured, '$existing_insure', '$policy_name', '$expiry_date',
//                            '$agent', '$expiring_sum', '$area_mtft', '$no_floor', '$no_wing', '$no_flat',
//                            '$totalbuild_area', '$area_perflat', $basement, '$basement_area', $meter_room,
//                            '$meter_area', $water_tank, '$water_tankcapacity', $inverter, '$inverter_time',
//                            $society_office, '$society_officearea', $ac, $water_pumps, $common, '$common_area',
//                            $sewage, $garbage, '$remark', $cctv, '$cctv_total', $fire_system, '$fire_systemtotal',
//                            $physical_security, '$no_gaurds', $audited, '$type', '$security_remark', '$power_back', $club,
//                            '$club_area', $swimming, '$swimming_area', '$inhouse', '$amenities_area', '$overall_remark')";
//
//    echo $sql_society;
//    $result_society = $conn->query($sql_society);
//    return $result_society;
//}
//


function societyinsert($name, $address, $email, $alternateemail, $manager, $manager_contact, $chairman, $chairman_contact, $secretary, $secretary_contact, $treasurer, $treasurer_contact, $insured, $existing_insure, $policy_name, $expiry_date, $agent, $expiring_sum, $area_mtft, $no_floor, $no_wing, $no_flat, $totalbuild_area, $area_perflat, $basement, $basement_area, $meter_room, $meter_area, $water_tank, $water_tankcapacity, $inverter, $inverter_time, $society_office, $society_officearea, $ac, $water_pumps, $common, $common_area, $sewage, $garbage, $remark, $cctv, $cctv_total, $fire_system, $fire_systemtotal, $physical_security, $no_gaurds, $audited, $type, $security_remark, $power_back, $club, $club_area, $swimming, $swimming_area, $inhouse, $amenities_area, $overall_remark, $login_id, $login_username) {
    global $conn;
    $sql_society = sprintf("INSERT INTO `society_table`(`name`, `address`, `email`, `alternateemail`, `manager`, `manager_contact`,
                            `chairman`, `chairman_contact`, `secretary`, `secretary_contact`, `treasurer`,
                            `treasurer_contact`, `insured`, `existing_insure`, `policy_name`, `expiry_date`,
                            `agent`, `expiring_sum`, `area_mtft`, `no_floor`, `no_wing`, `no_flat`,
                            `totalbuild_area`, `area_perflat`, `basement`, `basement_area`, `meter_room`,
                            `meter_area`, `water_tank`, `water_tankcapacity`, `inverter`, `inverter_time`,
                            `society_office`, `society_officearea`, `ac`, `water_pumps`, `common`, `common_area`,
                            `sewage`, `garbage`, `remark`, `cctv`, `cctv_total`, `fire_system`, `fire_systemtotal`,
                            `physical_security`, `no_gaurds`, `audited`, `type`, `security_remark`, `power_back`, `club`,
                            `club_area`, `swimming`, `swimming_area`, `inhouse`, `amenities_area`, `overall_remark`,`login_id`,`login_username`)
                            VALUES
                            ('%s', '%s', '%s', '%s', '%s', '%s',
                            '%s','%s','%s','%s','%s',
                            '%s', '%u', '%s', '%s','%s',
                            '%s', '%s', '%s', '%s', '%s', '%s',
                            '%s', '%s', '%u', '%s','%u',
                            '%s','%u','%s', '%u','%s',
                            '%u','%s', '%s', '%s','%u', '%s',
                            '%u','%u', '%s','%u', '%s','%u','%s',
                            '%u', '%s','%u','%s', '%s', '%s','%u',
                            '%s', '%u','%s','%s','%s','%s','%u','%s');", $name, $address, $email, $alternateemail, $manager, $manager_contact, $chairman, $chairman_contact, $secretary, $secretary_contact, $treasurer, $treasurer_contact, $insured, $existing_insure, $policy_name, $expiry_date, $agent, $expiring_sum, $area_mtft, $no_floor, $no_wing, $no_flat, $totalbuild_area, $area_perflat, $basement, $basement_area, $meter_room, $meter_area, $water_tank, $water_tankcapacity, $inverter, $inverter_time, $society_office, $society_officearea, $ac, $water_pumps, $common, $common_area, $sewage, $garbage, $remark, $cctv, $cctv_total, $fire_system, $fire_systemtotal, $physical_security, $no_gaurds, $audited, $type, $security_remark, $power_back, $club, $club_area, $swimming, $swimming_area, $inhouse, $amenities_area, $overall_remark, $login_id, $login_username);

    echo $sql_society;
    $result_society = $conn->query($sql_society);
    return $result_society;
}

//function societyshow() {
//    global $conn;
//
//    $societyshow_sql = "SELECT `id`, `name`, `address`, `email`, `alternateemail`, `manager`, `manager_contact`,
//                       `chairman`, `chairman_contact`, `secretary`, `secretary_contact`, `treasurer`,
//                       `treasurer_contact`, `insured`, `existing_insure`, `policy_name`, `expiry_date`,
//                       `agent`, `expiring_sum`, `area_mtft`, `no_floor`, `no_wing`, `no_flat`,
//                       `totalbuild_area`, `area_perflat`, `basement`, `basement_area`, `meter_room`,
//                       `meter_area`, `water_tank`, `water_tankcapacity`, `inverter`, `inverter_time`,
//                       `society_office`, `society_officearea`, `ac`, `water_pumps`, `common`, `common_area`,
//                       `sewage`, `garbage`, `remark`, `cctv`, `cctv_total`, `fire_system`, `fire_systemtotal`,
//                       `physical_security`, `no_gaurds`, `audited`, `type`, `security_remark`, `power_back`,
//                       `club`, `club_area`, `swimming`, `swimming_area`, `inhouse`, `amenities_area`, `overall_remark`
//                       FROM `society_table` WHERE 1";
//
//    $societyshow_result = $conn->query($societyshow_sql);
//    $data = array();
//    while ($row = mysqli_fetch_assoc($societyshow_result)) {
//        $data[] = $row;
//    }
//    return $data;
//}



function societyshow($loginid) {
    global $conn;

    $societyshow_sql = "SELECT `id`, `name`, `address`, `email`, `alternateemail`, `manager`, `manager_contact`,
                       `chairman`, `chairman_contact`, `secretary`, `secretary_contact`, `treasurer`,
                       `treasurer_contact`, `insured`, `existing_insure`, `policy_name`, `expiry_date`,
                       `agent`, `expiring_sum`, `area_mtft`, `no_floor`, `no_wing`, `no_flat`,
                       `totalbuild_area`, `area_perflat`, `basement`, `basement_area`, `meter_room`,
                       `meter_area`, `water_tank`, `water_tankcapacity`, `inverter`, `inverter_time`,
                       `society_office`, `society_officearea`, `ac`, `water_pumps`, `common`, `common_area`,
                       `sewage`, `garbage`, `remark`, `cctv`, `cctv_total`, `fire_system`, `fire_systemtotal`,
                       `physical_security`, `no_gaurds`, `audited`, `type`, `security_remark`, `power_back`,
                       `club`, `club_area`, `swimming`, `swimming_area`, `inhouse`, `amenities_area`, `overall_remark`,`login_id`,`login_username`
                       FROM `society_table` WHERE login_id=$loginid";

    $societyshow_result = $conn->query($societyshow_sql);
    $data = array();
    while ($row = mysqli_fetch_assoc($societyshow_result)) {
        $data[] = $row;
    }
    return $data;
}

function searchsociety($loginid_search, $namesociety) {
    global $conn;

    $searchsociety = "SELECT `id`, `name`, `address`, `email`, `alternateemail`, `manager`, `manager_contact`,
                      `chairman`, `chairman_contact`, `secretary`, `secretary_contact`, `treasurer`, `treasurer_contact`,
                      `insured`, `existing_insure`, `policy_name`, `expiry_date`, `agent`, `expiring_sum`, `area_mtft`,
                      `no_floor`, `no_wing`, `no_flat`, `totalbuild_area`, `area_perflat`, `basement`, `basement_area`,
                      `meter_room`, `meter_area`, `water_tank`, `water_tankcapacity`, `inverter`, `inverter_time`, `society_office`,
                      `society_officearea`, `ac`, `water_pumps`, `common`, `common_area`, `sewage`, `garbage`, `remark`,
                      `cctv`, `cctv_total`, `fire_system`, `fire_systemtotal`, `physical_security`, `no_gaurds`, `audited`, `type`,
                      `security_remark`, `power_back`, `club`, `club_area`, `swimming`, `swimming_area`,
                      `inhouse`, `amenities_area`, `overall_remark` FROM `society_table` WHERE login_id='" . $loginid_search . "' AND name like'" . $namesociety . "%'";


    $societysearch_result = $conn->query($searchsociety);
    $data = array();
    while ($row = mysqli_fetch_assoc($societysearch_result)) {
        $data[] = $row;
    }
    return $data;
}

function societyupdate($name, $address, $email, $alternateemail, $manager, $manager_contact, $chairman, $chairman_contact, $secretary, $secretary_contact, $treasurer, $treasurer_contact, $insured, $existing_insure, $policy_name, $expiry_date, $agent, $expiring_sum, $area_mtft, $no_floor, $no_wing, $no_flat, $totalbuild_area, $area_perflat, $basement, $basement_area, $meter_room, $meter_area, $water_tank, $water_tankcapacity, $inverter, $inverter_time, $society_office, $society_officearea, $ac, $water_pumps, $common, $common_area, $sewage, $garbage, $remark, $cctv, $cctv_total, $fire_system, $fire_systemtotal, $physical_security, $no_gaurds, $audited, $type, $security_remark, $power_back, $club, $club_area, $swimming, $swimming_area, $inhouse, $amenities_area, $overall_remark, $soc_updateid) {
    global $conn;
    $societyupdate_sql = "UPDATE `society_table` SET
                        `name`='$name',`address`='$address',`email`='$email',`alternateemail`='$alternateemail',
                        `manager`='$manager',`manager_contact`='$manager_contact',`chairman`='$chairman',`chairman_contact`='$chairman_contact',`secretary`='$secretary',
                        `secretary_contact`='$secretary_contact',`treasurer`='$treasurer',`treasurer_contact`='$treasurer_contact',`insured`=$insured,`existing_insure`='$existing_insure',
                        `policy_name`='$policy_name',`expiry_date`='$expiry_date',`agent`='$agent',`expiring_sum`='$expiring_sum',`area_mtft`='$area_mtft',`no_floor`='$no_floor',
                        `no_wing`='$no_wing',`no_flat`='$no_flat',`totalbuild_area`='$totalbuild_area',`area_perflat`='$area_perflat',
                        `basement`=$basement,`basement_area`='$basement_area',`meter_room`=$meter_room,`meter_area`='$meter_area',`water_tank`=$water_tank,
                        `water_tankcapacity`='$water_tankcapacity',`inverter`=$inverter,`inverter_time`='$inverter_time',`society_office`=$society_office,`society_officearea`='$society_officearea',
                        `ac`=$ac,`water_pumps`=$water_pumps,`common`=$common,`common_area`='$common_area',`sewage`=$sewage,
                        `garbage`=$garbage,`remark`='$remark',`cctv`=$cctv,`cctv_total`='$cctv_total',`fire_system`=$fire_system,
                        `fire_systemtotal`='$fire_systemtotal',`physical_security`=$physical_security,`no_gaurds`='$no_gaurds',`audited`=$audited,`type`='$type',
                        `security_remark`='$security_remark',`power_back`='$power_back',`club`=$club,`club_area`='$club_area',`swimming`=$swimming,
                        `swimming_area`='$swimming_area',`inhouse`='$inhouse',`amenities_area`='$amenities_area',`overall_remark`='$overall_remark' WHERE id=$soc_updateid";

    echo $soc_updateid;
    $societyupdate_result = $conn->query($societyupdate_sql);
    return $societyupdate_result;
}

function getsociety($id) {
    global $conn;
    $getsql = "SELECT `id`, `name`, `address`, `email`, `alternateemail`, `manager`, `manager_contact`, "
            . "`chairman`, `chairman_contact`, `secretary`, `secretary_contact`, `treasurer`, `treasurer_contact`,"
            . " `insured`, `existing_insure`, `policy_name`, `expiry_date`, `agent`, `expiring_sum`, `area_mtft`, "
            . "`no_floor`, `no_wing`, `no_flat`, `totalbuild_area`, `area_perflat`, `basement`, `basement_area`, "
            . "`meter_room`, `meter_area`, `water_tank`, `water_tankcapacity`, `inverter`, `inverter_time`, `society_office`, "
            . "`society_officearea`, `ac`, `water_pumps`, `common`, `common_area`, `sewage`, `garbage`, `remark`, `cctv`, "
            . "`cctv_total`, `fire_system`, `fire_systemtotal`, `physical_security`, `no_gaurds`, `audited`, `type`, `security_remark`, "
            . "`power_back`, `club`, `club_area`, `swimming`, `swimming_area`, `inhouse`, `amenities_area`, `overall_remark`"
            . " FROM `society_table` WHERE id=$id";
    $getresult = $conn->query($getsql);
    $data = array();
    while ($row = mysqli_fetch_assoc($getresult)) {
        $data[] = $row;
    }
    return $data;
}

/////////////////////////////////////////////////////////////--------Company---------/////////////////////////////////////////////////////////////
function insuranceinsert($name, $mobile, $email, $address, $insured, $home_loan, $home_date, $car_loan, $car_date, $health_loan, $health_date, $personal_loan, $personal_date, $dob, $occupation, $loan_type, $ifbusiness, $company_name, $no_employes, $type_business, $type_insurance, $office_loan, $office_date, $factory_loan, $factory_date, $gmc_loan, $gmc_date, $wc_loan, $wc_date, $liability_loan, $liability_date, $any_other, $specify, $login_id, $login_uname) {
    global $conn;
    $insurance_sql = "INSERT INTO `insurance_table`(`name`, `mobile`, `email`, `address`, `ifinsured`, `homeloan`,
        `homedate`, `carloan`, `cardate`, `healthloan`, `healthdate`, `personlloan`, `personaldate`, `dob`, `occupation`,
        `loantype`, `ifbusiness`, `companyname`, `noemploye`, `typebusiness`, `anyinsurance`, `officeloan`, `officedate`,
        `factoryloan`, `factorydate`, `gmcloan`, `gmcdate`, `wcloan`, `wcdate`, `liabilityloan`, `liabilitydate`, `anyother`, `specify`,`login_id`,`login_uname`)
             VALUES ('$name','$mobile','$email','$address',$insured,$home_loan,
                     '$home_date',$car_loan,'$car_date',$health_loan,'$health_date',$personal_loan,'$personal_date',
                     '$dob',$occupation,'$loan_type',$ifbusiness,'$company_name','$no_employes','$type_business',
                     $type_insurance,$office_loan,'$office_date',$factory_loan,'$factory_date',$gmc_loan,'$gmc_date',
                     $wc_loan,'$wc_date',$liability_loan,'$liability_date',$any_other,'$specify','$login_id','$login_uname')";
    echo $insurance_sql;
    $insurance_result = $conn->query($insurance_sql);
    return $insurance_result;
}

function insuranceshow($loginid_insurance) {
    global $conn;
    $insuranceshow_sql = "SELECT `id`, `name`, `mobile`, `email`, `address`, `ifinsured`,
                         `homeloan`, `homedate`, `carloan`, `cardate`, `healthloan`, `healthdate`,
                         `personlloan`, `personaldate`, `dob`, `occupation`, `loantype`, `ifbusiness`,
                         `companyname`, `noemploye`, `typebusiness`, `anyinsurance`, `officeloan`,
                         `officedate`, `factoryloan`, `factorydate`, `gmcloan`, `gmcdate`, `wcloan`,
                         `wcdate`, `liabilityloan`, `liabilitydate`, `anyother`, `specify` FROM `insurance_table` WHERE login_id=$loginid_insurance";

    $insuranceshow_result = $conn->query($insuranceshow_sql);
    $data = array();
    while ($row = mysqli_fetch_assoc($insuranceshow_result)) {
        $data[] = $row;
    }
    return $data;
}

function societydelete($societyid) {
    global $conn;
    $societydelete_sql = "DELETE FROM `society_table` WHERE id=$societyid";
    $societydelete_result = $conn->query($societydelete_sql);
    return $societydelete_result;
}

///////////////////////////////////-----insurnce serach-----///////////////////////////////

function searchinsurance($insid_search, $name) {
    global $conn;

    $insureancesearch_sql = "SELECT `id`, `name`, `mobile`, `email`, `address`, `ifinsured`,
                             `homeloan`, `homedate`, `carloan`, `cardate`, `healthloan`, `healthdate`,
                             `personlloan`, `personaldate`, `dob`, `occupation`, `loantype`, `ifbusiness`,
                             `companyname`, `noemploye`, `typebusiness`, `anyinsurance`, `officeloan`, `officedate`,
                             `factoryloan`, `factorydate`, `gmcloan`, `gmcdate`, `wcloan`, `wcdate`, `liabilityloan`,
                             `liabilitydate`, `anyother`, `specify` FROM `insurance_table` WHERE login_id='" . $insid_search . "' AND name like'" . $name . "%'";


    $search_result = $conn->query($insureancesearch_sql);
    $data = array();
    while ($row = mysqli_fetch_assoc($search_result)) {
        $data[] = $row;
    }
    return $data;
}

function insurancedelete($id) {
    global $conn;
    $insurancedelete_sql = "DELETE FROM `insurance_table` WHERE id=$id";
    $insurancedelete_result = $conn->query($insurancedelete_sql);
    return $insurancedelete_result;
}

function insuranceupdate($name, $mobile, $email, $address, $insured, $home_loan, $home_date, $car_loan, $car_date, $health_loan, $health_date, $personal_loan, $personal_date, $dob, $occupation, $loan_type, $ifbusiness, $company_name, $no_employes, $type_business, $type_insurance, $office_loan, $office_date, $factory_loan, $factory_date, $gmc_loan, $gmc_date, $wc_loan, $wc_date, $liability_loan, $liability_date, $any_other, $specify, $updateid) {
    global $conn;
    $insuranceupdate_sql = "UPDATE `insurance_table` SET
                           `name`='$name',`mobile`='$mobile',`email`='$email',`address`='$address',
                           `ifinsured`=$insured,`homeloan`=$home_loan,`homedate`='$home_date',`carloan`=$car_loan,`cardate`='$car_date',
                           `healthloan`=$health_loan,`healthdate`='$health_date',`personlloan`=$personal_loan,`personaldate`='$personal_date',`dob`='$dob',
                           `occupation`='$occupation',`loantype`='$loan_type',`ifbusiness`=$ifbusiness,`companyname`='$company_name',`noemploye`='$no_employes',
                           `typebusiness`='$type_business',`anyinsurance`=$type_insurance,`officeloan`=$office_loan,`officedate`='$office_date',`factoryloan`=$factory_loan,
                           `factorydate`='$factory_date',`gmcloan`=$gmc_loan,`gmcdate`='$gmc_date',`wcloan`=$wc_loan,`wcdate`='$wc_date',
                           `liabilityloan`=$liability_loan,`liabilitydate`='$liability_date',`anyother`='$any_other',`specify`='$specify' WHERE id=$updateid";

    echo $insuranceupdate_sql;

    $insuranceupdate_result = $conn->query($insuranceupdate_sql);
    return $insuranceupdate_result;
}

function getinsurance($id) {
    global $conn;
    $sql = "SELECT `id`, `name`, `mobile`, `email`, `address`, `ifinsured`, `homeloan`, `homedate`,
            `carloan`, `cardate`, `healthloan`, `healthdate`, `personlloan`, `personaldate`, `dob`,
            `occupation`, `loantype`, `ifbusiness`, `companyname`, `noemploye`, `typebusiness`,
            `anyinsurance`, `officeloan`, `officedate`, `factoryloan`, `factorydate`, `gmcloan`,
            `gmcdate`, `wcloan`, `wcdate`, `liabilityloan`, `liabilitydate`, `anyother`,
            `specify` FROM `insurance_table` WHERE id=$id";
    $result = $conn->query($sql);
    $data = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    return $data;
}

////////////////////////////////////////////////////////ADMIN Society/////////////////////////////////////////////////////////////
function admin_societyshow() {
    global $conn;

    $societyshow_sql = "SELECT `id`, `name`, `address`, `email`, `alternateemail`, `manager`, `manager_contact`,
                       `chairman`, `chairman_contact`, `secretary`, `secretary_contact`, `treasurer`,
                       `treasurer_contact`, `insured`, `existing_insure`, `policy_name`, `expiry_date`,
                       `agent`, `expiring_sum`, `area_mtft`, `no_floor`, `no_wing`, `no_flat`,
                       `totalbuild_area`, `area_perflat`, `basement`, `basement_area`, `meter_room`,
                       `meter_area`, `water_tank`, `water_tankcapacity`, `inverter`, `inverter_time`,
                       `society_office`, `society_officearea`, `ac`, `water_pumps`, `common`, `common_area`,
                       `sewage`, `garbage`, `remark`, `cctv`, `cctv_total`, `fire_system`, `fire_systemtotal`,
                       `physical_security`, `no_gaurds`, `audited`, `type`, `security_remark`, `power_back`,
                       `club`, `club_area`, `swimming`, `swimming_area`, `inhouse`, `amenities_area`, `overall_remark`,`login_id`,`login_username`
                       FROM `society_table` WHERE 1";

    $societyshow_result = $conn->query($societyshow_sql);
    $data = array();
    while ($row = mysqli_fetch_assoc($societyshow_result)) {
        $data[] = $row;
    }
    return $data;
}

function admin_searchsociety($namesociety) {
    global $conn;

    $searchsociety = "SELECT `id`, `name`, `address`, `email`, `alternateemail`, `manager`, `manager_contact`,
                      `chairman`, `chairman_contact`, `secretary`, `secretary_contact`, `treasurer`, `treasurer_contact`,
                      `insured`, `existing_insure`, `policy_name`, `expiry_date`, `agent`, `expiring_sum`, `area_mtft`,
                      `no_floor`, `no_wing`, `no_flat`, `totalbuild_area`, `area_perflat`, `basement`, `basement_area`,
                      `meter_room`, `meter_area`, `water_tank`, `water_tankcapacity`, `inverter`, `inverter_time`, `society_office`,
                      `society_officearea`, `ac`, `water_pumps`, `common`, `common_area`, `sewage`, `garbage`, `remark`,
                      `cctv`, `cctv_total`, `fire_system`, `fire_systemtotal`, `physical_security`, `no_gaurds`, `audited`, `type`,
                      `security_remark`, `power_back`, `club`, `club_area`, `swimming`, `swimming_area`,
                      `inhouse`, `amenities_area`, `overall_remark` FROM `society_table` WHERE name like'" . $namesociety . "%'";


    $societysearch_result = $conn->query($searchsociety);
    $data = array();
    while ($row = mysqli_fetch_assoc($societysearch_result)) {
        $data[] = $row;
    }
    return $data;
}

function admin_societyupdate($name, $address, $email, $alternateemail, $manager, $manager_contact, $chairman, $chairman_contact, $secretary, $secretary_contact, $treasurer, $treasurer_contact, $insured, $existing_insure, $policy_name, $expiry_date, $agent, $expiring_sum, $area_mtft, $no_floor, $no_wing, $no_flat, $totalbuild_area, $area_perflat, $basement, $basement_area, $meter_room, $meter_area, $water_tank, $water_tankcapacity, $inverter, $inverter_time, $society_office, $society_officearea, $ac, $water_pumps, $common, $common_area, $sewage, $garbage, $remark, $cctv, $cctv_total, $fire_system, $fire_systemtotal, $physical_security, $no_gaurds, $audited, $type, $security_remark, $power_back, $club, $club_area, $swimming, $swimming_area, $inhouse, $amenities_area, $overall_remark, $soc_updateid) {
    global $conn;
    $societyupdate_sql = "UPDATE `society_table` SET
                        `name`='$name',`address`='$address',`email`='$email',`alternateemail`='$alternateemail',
                        `manager`='$manager',`manager_contact`='$manager_contact',`chairman`='$chairman',`chairman_contact`='$chairman_contact',`secretary`='$secretary',
                        `secretary_contact`='$secretary_contact',`treasurer`='$treasurer',`treasurer_contact`='$treasurer_contact',`insured`=$insured,`existing_insure`='$existing_insure',
                        `policy_name`='$policy_name',`expiry_date`='$expiry_date',`agent`='$agent',`expiring_sum`='$expiring_sum',`area_mtft`='$area_mtft',`no_floor`='$no_floor',
                        `no_wing`='$no_wing',`no_flat`='$no_flat',`totalbuild_area`='$totalbuild_area',`area_perflat`='$area_perflat',
                        `basement`=$basement,`basement_area`='$basement_area',`meter_room`=$meter_room,`meter_area`='$meter_area',`water_tank`=$water_tank,
                        `water_tankcapacity`='$water_tankcapacity',`inverter`=$inverter,`inverter_time`='$inverter_time',`society_office`=$society_office,`society_officearea`='$society_officearea',
                        `ac`=$ac,`water_pumps`=$water_pumps,`common`=$common,`common_area`='$common_area',`sewage`=$sewage,
                        `garbage`=$garbage,`remark`='$remark',`cctv`=$cctv,`cctv_total`='$cctv_total',`fire_system`=$fire_system,
                        `fire_systemtotal`='$fire_systemtotal',`physical_security`=$physical_security,`no_gaurds`='$no_gaurds',`audited`=$audited,`type`='$type',
                        `security_remark`='$security_remark',`power_back`='$power_back',`club`=$club,`club_area`='$club_area',`swimming`=$swimming,
                        `swimming_area`='$swimming_area',`inhouse`='$inhouse',`amenities_area`='$amenities_area',`overall_remark`='$overall_remark' WHERE id=$soc_updateid";

    echo $soc_updateid;
    $societyupdate_result = $conn->query($societyupdate_sql);
    return $societyupdate_result;
}

////////////////////////////////////////////////////////ADMIN Insurance/////////////////////////////////////////////////////////////
function admin_searchinsurance($name) {
    global $conn;

    $insureancesearch_sql = "SELECT `id`, `name`, `mobile`, `email`, `address`, `ifinsured`,
                             `homeloan`, `homedate`, `carloan`, `cardate`, `healthloan`, `healthdate`,
                             `personlloan`, `personaldate`, `dob`, `occupation`, `loantype`, `ifbusiness`,
                             `companyname`, `noemploye`, `typebusiness`, `anyinsurance`, `officeloan`, `officedate`,
                             `factoryloan`, `factorydate`, `gmcloan`, `gmcdate`, `wcloan`, `wcdate`, `liabilityloan`,
                             `liabilitydate`, `anyother`, `specify`,`login_id`, `login_uname` FROM `insurance_table` WHERE name like'" . $name . "%'";


    $search_result = $conn->query($insureancesearch_sql);
    $data = array();
    while ($row = mysqli_fetch_assoc($search_result)) {
        $data[] = $row;
    }
    return $data;
}

function admin_insuranceshow() {
    global $conn;
    $insuranceshow_sql = "SELECT `id`, `name`, `mobile`, `email`, `address`, `ifinsured`,
                         `homeloan`, `homedate`, `carloan`, `cardate`, `healthloan`, `healthdate`,
                         `personlloan`, `personaldate`, `dob`, `occupation`, `loantype`, `ifbusiness`,
                         `companyname`, `noemploye`, `typebusiness`, `anyinsurance`, `officeloan`,
                         `officedate`, `factoryloan`, `factorydate`, `gmcloan`, `gmcdate`, `wcloan`,
                         `wcdate`, `liabilityloan`, `liabilitydate`, `anyother`, `specify`,`login_id`, `login_uname` FROM `insurance_table` WHERE 1";

    $insuranceshow_result = $conn->query($insuranceshow_sql);
    $data = array();
    while ($row = mysqli_fetch_assoc($insuranceshow_result)) {
        $data[] = $row;
    }
    return $data;
}

?>