$(function(){
$('a[title]').tooltip();
});
