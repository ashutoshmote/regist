

<?php
include '../databaseconnection/databasesociety.php';
$societyoutput = "";
if (isset($_REQUEST['soc_name'])) {
    if (!empty($_POST['soc_name'])) {
        $one2 = $_POST['soc_name'];
        $one3 = $_POST['soc_address'];
        $one4 = $_POST['soc_email'];
        $one5 = $_POST['soc_altemail'];
        $one6 = $_POST['manager'];
        $one7 = $_POST['man_contact'];
        $one8 = $_POST['chairman'];
        $one9 = $_POST['chair_contact'];
        $one10 = $_POST['secretary'];
        $one11 = $_POST['sec_contact'];
        $one12 = $_POST['treasurer'];
        $one13 = $_POST['tre_contact'];
        $one14 = $_POST['insured'];
        $one15 = $_POST['existing_insure'];
        $one16 = $_POST['policy_name'];
        $one17 = $_POST['expiry_date'];
        $one18 = $_POST['agent'];
        $one19 = $_POST['expiring_sum'];

        $cal = $area = $_POST['area'] . " " . $area_sq = $_POST['area_sq'];
        $one20 = $cal;

        $one21 = $_POST['floor'];
        $one22 = $_POST['wing'];
        $one23 = $_POST['flat'];

        $totalbuildcal = $totalbuildarea = $_POST['totalbuild'] . " " . $totalbuildarea_sq = $_POST['totalbuildarea_sq'];
        $one24 = $totalbuildcal;

        $perflatcal = $perflatarea = $_POST['perflat'] . " " . $perflatarea_sq = $_POST['perflatarea_sq'];
        $one25 = $perflatcal;


        $one26 = $_POST['base'];

        $basementcal = $basementarea = $_POST['basearea'] . " " . $basementarea_sq = $_POST['basearea_sq'];
        $one27 = $basementcal;

        $one28 = $_POST['meter'];

        $metercal = $meterarea = $_POST['meterarea'] . " " . $meterarea_sq = $_POST['meterarea_sq'];
        $one29 = $metercal;


        $one30 = $_POST['tank'];
        $one31 = $_POST['water_capacity'];
        $one32 = $_POST['invdg'];
        $one33 = $_POST['inverterhrs'];

        $one34 = $_POST['societyoffice'];

        $societyofficecal = $societyofficearea = $_POST['societyoffice_area'] . " " . $societyofficearea_sq = $_POST['societyarea_sq'];
        $one35 = $societyofficecal;

        $one36 = $_POST['ac'];
        $one37 = $_POST['waterpump'];

        $one38 = $_POST['commonarea'];
        $commonareacal = $commonarea = $_POST['common_area'] . " " . $commonarea_sq = $_POST['commonarea_sq'];
        $one39 = $commonareacal;
        $one40 = $_POST['sewage'];
        $one41 = $_POST['garbage'];
        $one42 = $_POST['soc_remark'];
        $one43 = $_POST['cctv'];
        $one44 = $_POST['cctvtotal'];
        $one45 = $_POST['fire'];
        $one46 = $_POST['firetotal'];
        $one47 = $_POST['physicalsecurity'];
        $one48 = $_POST['gaurd'];
        $one49 = $_POST['audited'];
        $one50 = $_POST['type'];
        $one51 = $_POST['security_remark'];
        $one52 = $_POST['powerback'];
        $one53 = $_POST['clubhouse'];
        $clubhousecal = $clubhousearea = $_POST['clubarea'] . " " . $clubhousearea_sq = $_POST['clubarea_sq'];
        $one54 = $clubhousecal;
        $one55 = $_POST['swimming'];
        $swimmingcal = $swimmingarea = $_POST['swimingarea'] . " " . $swimmingarea_sq = $_POST['swimingarea_sq'];
        $one56 = $swimmingcal;
        $one57 = $_POST['inhouse'];

        $amenitiescal = $amenitiesarea = $_POST['amenities_area'] . " " . $amenitiesarea_sq = $_POST['inhousearea_sq'];
        $one58 = $amenitiescal;
        $one59 = $_POST['overallremark'];

        $societyresult = societyinsert($one2, $one3, $one4, $one5, $one6, $one7, $one8, $one9, $one10, $one11, $one12, $one13, $one14, $one15, $one16, $one17, $one18, $one19, $one20, $one21, $one22, $one23, $one24, $one25, $one26, $one27, $one28, $one29, $one30, $one31, $one32, $one33, $one34, $one35, $one36, $one37, $one38, $one39, $one40, $one41, $one42, $one43, $one44, $one45, $one46, $one47, $one48, $one49, $one50, $one51, $one52, $one53, $one54, $one55, $one56, $one57, $one58, $one59);
        if ($societyresult > 0) {
            header("Location:society.php");
        } else {
            echo "<div class='alert alert-danger'>" . " <strong>Unsuccess!</strong> " . "</div>";
        }
    }
}
?>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Dashboard</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="newcss.css" rel="stylesheet" type="text/css"/>
        <link href="https://fonts.googleapis.com/css?family=Montserrat|Oswald|Roboto|Roboto+Condensed&display=swap" rel="stylesheet">
        <link href="../assets/dash.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>

        <div class="container">
            <div class="row">
                <div class="tab" role="tabpanel">

                    <br>


                    <form method="post" id="register_form">
                        <ul class="nav nav-tabs">
                            <li role="presentation" class="nav-item">
                                <a class="nav-link active_tab1"  id="list_basic_details">Society Details</a>
                            </li>
                            <li role="presentation" class="nav-item">
                                <a class="nav-link inactive_tab1" id="list_member_details">Society Member Details</a>
                            </li>
                            <li role="presentation" class="nav-item">
                                <a class="nav-link inactive_tab1" id="list_insured_details" >Security Measures</a>
                            </li>
                        </ul>
                        <div class="tab-content" style="margin-top:16px;">
                            <div  role="tabpanel" class="tab-pane fade in active" id="basic_details">
                                <div class="panel panel-default">
                                    <div class="panel-heading">Society Details</div>
                                    <div class="panel-body">
                                        <div class="form-group">
                                            <label>Society Name</label>
                                            <input type="text" name="soc_name" id="socname" class="form-control" />
                                            <span id="error_society" class="text-danger"></span>
                                        </div>
                                        <div class="form-group">
                                            <label>Enter Address</label>
                                            <textarea name="soc_address" id="address" class="form-control"></textarea>
                                            <span id="error_address" class="text-danger"></span>
                                        </div>
                                        <div class="form-group">
                                            <label>Enter Email Address</label>
                                            <input type="text" name="soc_email" id="email" class="form-control" />
                                            <span id="error_email" class="text-danger"></span>
                                        </div>
                                        <div class="form-group">
                                            <label>Enter Email Address</label>
                                            <input type="text" name="soc_altemail" id="alter_email" class="form-control" />
                                            <span id="error_alteremail" class="text-danger"></span>
                                        </div>
                                        <br />
                                        <div align="center">
                                            <button type="button" name="btnbasic_details" id="btn_basic_details" class="btn btn-info btn-lg">
                                                <i class="fa fa-arrow-circle-right" aria-hidden="true"></i> Next</button>
                                        </div>
                                        <br />
                                    </div>
                                </div>
                            </div>
                            <!--<////////////////--Member Details--//////////////////>                    -->
                            <div  role="tabpanel" class="tab-pane fade" id="member_details">
                                <div class="panel panel-default">
                                    <div class="panel-heading">Fill Personal Details</div>
                                    <div class="panel-body">

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter Manager Email</label>
                                                    <input type="text" name="manager" id="manager_email" class="form-control" />
                                                    <span id="error_manager_email" class="text-danger"></span>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter Manager Contact</label>
                                                    <input type="text" name="man_contact" id="manager_contact" class="form-control" />
                                                    <span id="error_manager_contact" class="text-danger"></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter Chairman Email</label>
                                                    <input type="text" name="chairman" id="chairman_email" class="form-control" />
                                                    <span id="error_chairman_email" class="text-danger"></span>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter Chairman Contact</label>
                                                    <input type="text" name="chair_contact" id="chairman_contact" class="form-control" />
                                                    <span id="error_chairman_contact" class="text-danger"></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter Secretary Email</label>
                                                    <input type="text" name="secretary" id="secretary_email" class="form-control" />
                                                    <span id="error_secretary_email" class="text-danger"></span>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter Secretary Conatct</label>
                                                    <input type="text" name="sec_contact" id="secretary_contact" class="form-control" />
                                                    <span id="error_secretary_contact" class="text-danger"></span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter Treasurer Email</label>
                                                    <input type="text" name="treasurer" id="treasurer_name" class="form-control" />
                                                    <span id="error_treasurer_name" class="text-danger"></span>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter Treasurer Contact</label>
                                                    <input type="text" name="tre_contact" id="treasurer_contact" class="form-control" />
                                                    <span id="error_treasurer_contact" class="text-danger"></span>
                                                </div>
                                            </div>
                                        </div>





                                        <br />
                                        <div align="center">
                                            <button type="button" name="previous_btn_personal_details" id="previous_btn_member_details" class="btn btn-warning btn-lg">
                                                <i class="fa fa-arrow-circle-left" aria-hidden="true"></i> Previous</button>
                                            <button type="button" name="btn_personal_details" id="btn_member_details" class="btn btn-info btn-lg">
                                                <i class="fa fa-arrow-circle-right" aria-hidden="true"></i> Next</button>
                                        </div>
                                        <br />
                                    </div>
                                </div>
                            </div>


                            <div  role="tabpanel" class="tab-pane fade" id="insured_details">
                                <div class="panel panel-default">
                                    <div class="panel-heading">Fill Contact Details</div>
                                    <!--                            <Start  Insured Part >-->
                                    <div class="panel-body">
                                        <div class="form-group" style="font-size:18px;font-weight: 500">
                                            <label for="seeAnotherField">Society Insuerd/Uninsured:</label>
                                            <select class="form-control" id="seeAnotherField" name="insured" required style="font-size:18px;font-weight: 500">
                                                <option value="">choose One</option>
                                                <option value="1">Insured</option>
                                                <option value="2">Uninsured</option>
                                            </select>
                                        </div>

                                        <div class="panel-body" id="1">

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">

                                                        <label for="otherField1">1)Existing insure:</label>
                                                        <input type="text" class="form-control w-100"  name="existing_insure" id="otherField1">
                                                        <span id="error_insure" class="text-danger"></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="otherField2">2)Policy Name:</label>
                                                        <input type="text" class="form-control w-100" name="policy_name" id="otherField2">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="otherField3">3)Expiry Date</label>
                                                        <input type="date" class="form-control w-100" name="expiry_date" id="otherField3">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="otherField4">4)Agent/Broker Name:</label>
                                                        <input type="text" class="form-control w-100" onkeyup="letter(this)"  name="agent" id="otherField4">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="otherField5">5)Expiring sum insured:</label>
                                                <input type="text" class="form-control w-100" onkeyup="letter(this)" name="expiring_sum" id="otherField5">
                                            </div>




                                        </div>

                                        <!--                            <End Insured Part >-->



                                        <!--                            <START  UnInsured Part >-->
                                        <div class="panel-body" id="otherFieldDiv">
                                            <div class="responsive-tabs" style="font-size:15px">
                                                <ul class="nav nav-tabs" role="tablist">
                                                    <li role="presentation" class="active">
                                                        <a href="#tab1" aria-controls="tab1" role="tab" data-toggle="tab">Society Area</a>
                                                    </li>
                                                    <li role="presentation" class="">
                                                        <a href="#tab2" aria-controls="tab2" role="tab" data-toggle="tab">Security Measures</a>
                                                    </li>
                                                    <li role="presentation" class="">
                                                        <a href="#tab3" aria-controls="tab3" role="tab" data-toggle="tab">Other Amenities</a>
                                                    </li>
                                                </ul>


                                                <div id="tabs-content" class="tab-content panel-group">
                                                    <div class="panel-heading" role="tab" id="heading1">
                                                        <a href="#tab1" class="" role="button" data-toggle="collapse" data-parent="tabs-content" aria-expanded="true"
                                                           aria-controls="tab1">Tab 1</a>
                                                    </div>

                                                    <div id="tab1" role="tabpanel" class="tab-pane active panel-collapse collapse in" aria-labelledby="heading1">
                                                        <br>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="otherFieldarea">1) Area:</label>
                                                                    <input type="text" class="form-control"  name="area" id="otherFieldarea">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label>Area Sq ft/mtr:</label>
                                                                    <select class="form-control" name="area_sq">
                                                                        <option value="SquareMeters">Square Meters</option>
                                                                        <option value="SquareFeet">Square Feet </option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="otherField_wing">2)No of Floor:</label>
                                                            <input type="text" class="form-control w-100" onkeyup="alphnumeric(this)" name="floor" id="otherField_wing">
                                                        </div>


                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="otherField_wing">3) No of Wings:</label>
                                                                    <input type="text" class="form-control w-100" onkeyup="alphnumeric(this)" name="wing" id="otherField_wing">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="otherField_flat">4) No of Flats:</label>
                                                                    <input type="text" class="form-control w-100" onkeyup="alphnumeric(this)"  name="flat" id="otherField_flat">
                                                                </div>
                                                            </div>
                                                        </div>


                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="otherField_build">5) Total Build up area</label>
                                                                    <input type="text" class="form-control w-100" onkeyup="alphnumeric(this)" name="totalbuild" id="otherField_build">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label>Total Build Area Sq ft/mtr:</label>
                                                                    <select class="form-control" name="totalbuildarea_sq">
                                                                        <option value="SquareMeters">Square Meters</option>
                                                                        <option value="SquareFeet">Square Feet </option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="otherField_perflat">6) Area per Flat (sq ft/mtr):</label>
                                                                    <input type="text" class="form-control w-100" onkeyup="alphnumeric(this)" name="perflat" id="otherField_perflat">
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label>Flat Area Sq ft/mtr:</label>
                                                                    <select class="form-control" name="perflatarea_sq">
                                                                        <option value="SquareMeters">Square Meters</option>
                                                                        <option value="SquareFeet">Square Feet </option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <h5>7) Basement</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="basYes" name="base" value="1" onclick="basement()">
                                                                        <label class="custom-control-label" for="basYes">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="basNo" name="base" value="0" onclick="basement()" checked>
                                                                        <label class="custom-control-label" for="basNo">No</label>
                                                                    </div>
                                                                </div>
                                                                <div id="dvbas" style="display: none">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <input type="text" name="basearea" id="basetext" class="form-control w-100"/>
                                                                            </div></div>

                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <select class="form-control" name="basearea_sq">
                                                                                    <option value="SquareMeters">Square Meters</option>
                                                                                    <option value="SquareFeet">Square Feet </option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <div class="form-group">
                                                                        <h5>8) Meter Room/Pump House?</h5>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="meterYes" name="meter" value="0" onclick="meterroom()" >
                                                                            <label class="custom-control-label" for="meterYes">Yes</label>
                                                                        </div>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="meterNo" name="meter" value="1" onclick="meterroom()" checked>
                                                                            <label class="custom-control-label" for="meterNo">No</label>
                                                                        </div>
                                                                    </div>
                                                                    <div id="meterbas" style="display: none">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <input type="text" name="meterarea" class="form-control w-100"/>
                                                                                </div></div>

                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <select class="form-control" name="meterarea_sq">
                                                                                        <option value="SquareMeters">Square Meters</option>
                                                                                        <option value="SquareFeet">Square Feet </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--<///////////////////////////////>-->
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <h5>9) OH/UG Water Tanks:</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="tankYes" name="tank" value="1" onclick="watertank()">
                                                                        <label class="custom-control-label" for="tankYes">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="tankNo" name="tank" value="0" onclick="watertank()" checked >
                                                                        <label class="custom-control-label" for="tankNo">No</label>
                                                                    </div>
                                                                </div>
                                                                <div id="dvtank" style="display: none">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <input type="text" name="water_capacity" placeholder="water" class="form-control w-100"/>
                                                                            </div></div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <div class="form-group">
                                                                        <h5>10) Inverter & DG Set</h5>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="iYes" name="invdg" value="1" onclick="inverter()">
                                                                            <label class="custom-control-label" for="iYes">Yes</label>
                                                                        </div>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="iNo" name="invdg" value="0" onclick="inverter()" checked>
                                                                            <label class="custom-control-label" for="iNo">No</label>
                                                                        </div>
                                                                    </div>
                                                                    <div id="dvinverter" style="display: none">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <input type="time" id="time" name="inverterhrs" placeholder="" class="form-control w-100"/>
                                                                                </div></div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--<///////////////////////////////>-->

                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <h5>11) Society Office:</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="societyoffice1" name="societyoffice" value="1"  onclick="office()" >
                                                                        <label class="custom-control-label" for="societyoffice1">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="societyoffice2" name="societyoffice" value="0" onclick="office()" checked >
                                                                        <label class="custom-control-label" for="societyoffice2">No</label>
                                                                    </div>
                                                                </div>
                                                                <div id="dvoffice" style="display: none">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <input type="text" name="societyoffice_area" placeholder="" class="form-control w-100"/>
                                                                            </div></div>

                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <select class="form-control" name="societyarea_sq">
                                                                                    <option value="SquareMeters">Square Meters</option>
                                                                                    <option value="SquareFeet">Square Feet </option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <div class="form-group">
                                                                        <h5>12) AC's:</h5>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="ac1" name="ac" value="0"  >
                                                                            <label class="custom-control-label" for="ac1">Yes</label>
                                                                        </div>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="ac2" name="ac" value="1" checked >
                                                                            <label class="custom-control-label" for="ac2">No</label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!--<///////////////////////////////>-->


                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <h5>13) water Pumps:</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="waterpump1" name="waterpump" value="1"  >
                                                                        <label class="custom-control-label" for="waterpump1">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="waterpump2" name="waterpump" value="0" checked >
                                                                        <label class="custom-control-label" for="waterpump2">No</label>
                                                                    </div>
                                                                </div>


                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <div class="form-group">
                                                                        <h5>14) Common Area Funtime and Fixtures:</h5>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="commonarea1" name="commonarea" value="1" onclick="common()"  >
                                                                            <label class="custom-control-label" for="commonarea1">Yes</label>
                                                                        </div>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="commonarea2" name="commonarea" value="0" onclick="common()" checked >
                                                                            <label class="custom-control-label" for="commonarea2">No</label>
                                                                        </div>
                                                                    </div>
                                                                    <div id="dvcommonarea" style="display: none">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <input type="text" name="common_area" class="form-control w-100"/>
                                                                                </div></div>

                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <select class="form-control" name="commonarea_sq">
                                                                                        <option value="SquareMeters">Square Meters</option>
                                                                                        <option value="SquareFeet">Square Feet </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>





                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <h5>15) Sewage Treatment Plant:</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="sewage1" name="sewage" value="1"  >
                                                                        <label class="custom-control-label" for="sewage1">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="sewage2" name="sewage" value="0" checked >
                                                                        <label class="custom-control-label" for="sewage2">No</label>
                                                                    </div>
                                                                </div>


                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <h5>16) Garbage Recycling Machine:</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="garbage1" name="garbage" value="1"  >
                                                                        <label class="custom-control-label" for="garbage1">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="garbage2" name="garbage" value="0" checked >
                                                                        <label class="custom-control-label" for="garbage2">No</label>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <h5>Remark:</h5>
                                                            <textarea class="form-control" rows="2" onkeyup="alphnumeric(this)" name="soc_remark" ></textarea>
                                                        </div>
                                                    </div>
                                                    <!-- <///////////////-------END TAB1--------/////////////////>-->

                                                    <div class="panel-heading" role="tab" id="heading2">
                                                        <a href="#tab2" class="collapsed" role="button" data-toggle="collapse" data-parent="tabs-content"
                                                           aria-expanded="true" aria-controls="tab2">Tab 2</a>
                                                    </div>

                                                    <div id="tab2" role="tabpanel" class="tab-pane panel-collapse collapse" aria-labelledby="heading2">

                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <h5>CCTV Camera:</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="cctv1" name="cctv" value="1" onclick="cctv_camera()"  >
                                                                        <label class="custom-control-label" for="cctv1">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="cctv2" name="cctv" value="0" onclick="cctv_camera()" checked >
                                                                        <label class="custom-control-label" for="cctv2">No</label>
                                                                    </div>
                                                                </div>
                                                                <div id="dvcamera" style="display: none">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <input type="text" name="cctvtotal" id="basetext" class="form-control w-100"/>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <div class="form-group">
                                                                        <h5>Fire Fighting System:</h5>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="fire1" name="fire" value="1" onclick="firesystem()"   >
                                                                            <label class="custom-control-label" for="fire1">Yes</label>
                                                                        </div>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="fire2" name="fire" value="0" onclick="firesystem()" checked >
                                                                            <label class="custom-control-label" for="fire2">No</label>
                                                                        </div>
                                                                    </div>
                                                                    <div id="dvfire" style="display: none">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <input type="text" name="firetotal" class="form-control w-100"/>
                                                                                </div></div>

                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <h5>Physical Security 24/7:</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="physicalsecurity1" name="physicalsecurity" value="1" onclick="security()" >
                                                                        <label class="custom-control-label" for="physicalsecurity1">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="physicalsecurity2" name="physicalsecurity" value="0" onclick="security()" checked >
                                                                        <label class="custom-control-label" for="physicalsecurity2">No</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6" id="dvgaurds" style="display: none">
                                                                <div class="form-group">
                                                                    <h5 for="otherField_gaurd">No of Gaurds:</h5>
                                                                    <input type="text" class="form-control" onkeyup="alphnumeric(this)" name="gaurd">
                                                                </div>
                                                            </div>
                                                        </div>



                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <h5>Audited:</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="audited1" name="audited" value="1"  >
                                                                        <label class="custom-control-label" for="audited1">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="audited2" name="audited" value="0" checked >
                                                                        <label class="custom-control-label" for="audited2">No</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <h5>Type</h5>
                                                                    <input type="text" class="form-control" onkeyup="alphnumeric(this)" name="type">
                                                                </div>
                                                            </div>
                                                        </div>


                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <h5>Remark:</h5>
                                                                    <textarea class="form-control" rows="2" onkeyup="alphnumeric(this)" name="security_remark" ></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <h5>Power Back System :</h5>
                                                                    <textarea class="form-control" onkeyup="alphnumeric(this)" rows="2" name="powerback" ></textarea>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>

                                                    <!-- <///////////////-------END TAB2--------/////////////////>-->
                                                    <div class="panel-heading" role="tab" id="heading3">
                                                        <a href="#tab3" class="collapsed" role="button" data-toggle="collapse" data-parent="tabs-content"
                                                           aria-expanded="true" aria-controls="tab3">Tab 3</a>
                                                    </div>

                                                    <div id="tab3" role="tabpanel" class="tab-pane panel-collapse collapse" aria-labelledby="heading3">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <h5>Club House/Gym:</h5>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="clubhouse1" name="clubhouse" value="1" onclick="club()"  >
                                                                        <label class="custom-control-label" for="clubhouse1">Yes</label>
                                                                    </div>
                                                                    <div class="custom-control radio-inline custom-control-inline">
                                                                        <input type="radio" class="custom-control-input" id="clubhouse2" name="clubhouse" value="0" onclick="club()" checked >
                                                                        <label class="custom-control-label" for="clubhouse2">No</label>
                                                                    </div>
                                                                </div>
                                                                <div id="dvclub" style="display: none">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <input type="text" name="clubarea" id="basetext" class="form-control w-100"/>
                                                                            </div></div>

                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                                <select class="form-control" name="clubarea_sq">
                                                                                    <option value="SquareMeters">Square Meters</option>
                                                                                    <option value="SquareFeet">Square Feet </option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <div class="form-group">
                                                                        <h5>Swimming Pool:</h5>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="swimming1" name="swimming" value="1" onclick="pool()"  >
                                                                            <label class="custom-control-label" for="swimming1">Yes</label>
                                                                        </div>
                                                                        <div class="custom-control radio-inline custom-control-inline">
                                                                            <input type="radio" class="custom-control-input" id="swimming2" name="swimming" value="0" onclick="pool()" checked >
                                                                            <label class="custom-control-label" for="swimming2">No</label>
                                                                        </div>
                                                                    </div>
                                                                    <div id="dvpool" style="display: none">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <input type="text"  name="swimingarea"  class="form-control w-100"/>
                                                                                </div></div>

                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    <select class="form-control" name="swimingarea_sq">
                                                                                        <option value="SquareMeters">Square Meters</option>
                                                                                        <option value="SquareFeet">Square Feet </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <h5>Inhouse/Separate Building:</h5>
                                                                    <input type="text" class="form-control" onkeyup="alphnumeric(this)" name="inhouse">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">

                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <h5>Area:</h5>
                                                                            <input type="text" class="form-control" onkeyup="alphnumeric(this)" name="amenities_area">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-6">
                                                                        <div class="form-group">
                                                                            <h5>sq mtr/sq ft:</h5>
                                                                            <select class="form-control" name="inhousearea_sq">
                                                                                <option value="SquareMeters">Square Meters</option>
                                                                                <option value="SquareFeet">Square Feet </option>
                                                                            </select>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <h5>Overall observation/Remarks:</h5>
                                                                    <textarea class="form-control" onkeyup="alphnumeric(this)" name="overallremark"></textarea>
                                                                </div>
                                                            </div>

                                                        </div>

                                                    </div>
                                                    <!-- <///////////////-------END TAB3--------/////////////////>-->
                                                </div>
                                            </div>



                                        </div>


                                        <br />
                                        <div align="center">
                                            <button type="button" name="previous_btn_contact_details" id="previous_btn_insured_details" class="btn btn-warning btn-lg">
                                                <i class="fa fa-arrow-circle-left" aria-hidden="true"></i> Previous</button>
                                            <button type="button" name="btn_contact_details" id="btn_insured_details" class="btn btn-success btn-lg">
                                                <i class="fa fa-send-o fa-lg"></i> Register</button>
                                        </div>
                                        <br />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
        <br />
        <script src='http://code.jquery.com/jquery-latest.js'></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.js"></script>
        <script src="../Society/society.js" type="text/javascript"></script>
        <script src="../Society/insured.js" type="text/javascript"></script>
        <script src="../assets/dash.js" type="text/javascript"></script>
        <script src="newjavascript.js" type="text/javascript"></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>

    </body></html>